﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;

namespace AdvanceFeaturesDemoApp.Views
{
    public partial class LoginPage : Page
    {
        public LoginPage()
        {
            InitializeComponent();
        }

        // Executes when the user navigates to this page.
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            //call your WCF authentication service here and validate the user
            //set application level boolean flag as per result received from the service
            //For demo purpose, I am only checking the supplied credentials against string 
            if (txtUserID.Text == "Ashish" && txtPassword.Password=="123456")
            {
                App.IsLoggedIn = true;
                this.NavigationService.Navigate(new Uri("/Home", UriKind.Relative));
            }
            else
            {
                ErrorWindow ew = new ErrorWindow("Incorrect Login", "The login credentials you supplied are not correct. Please try again");
                ew.Title = "Login error";
                ew.IntroductoryText.Text = "";
                ew.Show();
            }

        }


    }
}
