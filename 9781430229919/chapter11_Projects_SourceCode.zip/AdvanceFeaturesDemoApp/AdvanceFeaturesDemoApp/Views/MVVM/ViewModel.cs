﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
//added
using System.Runtime.InteropServices.Automation;
using System.Collections.Generic;
using System.Collections;

namespace AdvanceFeaturesDemoApp.Views.MVVM
{
    public class ViewModel
    {
        //public properties 
        public IEnumerable Books
        {
            get{
            //call to GetBooks of Model class
            return BookData.GetBooks();
            }
        }
        public ICommand COMCommand
        {
            get {
                return new COMCommand(this);}
            
        }

        public void WordExport()
        {
            dynamic word = AutomationFactory.CreateObject("Word.Application");
            word.Visible = true;

            dynamic wordDocument = word.Documents.Add();
            dynamic range = wordDocument.Range(0, 0);
            dynamic table = wordDocument.Tables.Add(range, 5, 4);

            //some property setting on table
            table.ApplyStyleHeadingRows = true;
            table.AllowAutoFit = true;

            //setting header
            table.Cell(1, 1).Range.Text = "Title";
            table.Cell(1, 2).Range.Text = "Author";
            table.Cell(1, 3).Range.Text = "ISBN";
            table.Cell(1, 4).Range.Text = "URL";

            int j = 2;
            foreach (Book item in Books) //ch
            {

                table.Cell(j, 1).Range.Text = item.Title;
                table.Cell(j, 2).Range.Text = item.Author;
                table.Cell(j, 3).Range.Text = item.isbn;
                table.Cell(j, 4).Range.Text = item.Url;
                j++;
            }
        }

        public void ExcelExport()
        {
            // create an instance of excel
            dynamic excel = AutomationFactory.CreateObject("Excel.Application");

            excel.Visible = true;  // make it visible to the user.

            // add a workbook to the instance 
            dynamic workbook = excel.workbooks;
            workbook.Add();

            dynamic sheet = excel.ActiveSheet; // get the active sheet

            dynamic cell = null;

            int i = 1;

            // iterate through our data source and populate the excel spreadsheet
            foreach (Book item in Books) //ch
            {

                cell = sheet.Cells[i, 1]; // row, column
                cell.Value = item.Title;
                cell.ColumnWidth = 25;

                cell = sheet.Cells[i, 2];
                cell.Value = item.Author;

                cell = sheet.Cells[i, 3];
                cell.Value = item.isbn;


                cell = sheet.Cells[i, 4];
                cell.Value = item.Url;

                i++;
            }
        }

    }

    public class COMCommand : ICommand
    {
        private ViewModel _vm;

        public COMCommand(ViewModel vm)
        {
            _vm = vm;
        }

        public bool CanExecute(object parameter)
        {
            return true;
        }

        public event EventHandler CanExecuteChanged;

        public void Execute(object parameter)
        {
             
            if (parameter.ToString()=="Word")
            {
                _vm.WordExport();
            }

            else //it is Excel export button clicked
            {
                _vm.ExcelExport();
            }
        }
    }
}
