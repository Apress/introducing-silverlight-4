﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
//added
//using System.Collections.Generic;
using System.Collections;

namespace AdvanceFeaturesDemoApp.Views.MVVM
{
    public class Book
    {
        public string Title { get; set; }
        public string Author { get; set; }
        public string isbn { get; set; }
        public string Url { get; set; }
    }

    public class BookData
    {
        public static IEnumerable GetBooks()
        {
            Book[] books = new Book[4];

            books[0] = new Book();
            books[0].Title = "Accelerated Silverlight 2";
            books[0].Author = "Jeff Scanlon";
            books[0].isbn = "978-1-4302-1076-4";
            books[0].Url = @"http://apress.com/book/view/9781430210764";

            books[1] = new Book();
            books[1].Title = "Accelerated Silverlight 3";
            books[1].Author = "Ashish Ghoda, Jeff Scanlon";
            books[1].isbn = "978-1-4302-2429-7";
            books[1].Url = @"http://apress.com/book/view/9781430224297";

            books[2] = new Book();
            books[2].Title = "Introducing Silverlight 4";
            books[2].Author = "Ashish Ghoda";
            books[2].isbn = "978-1-4302-2991-9";
            books[2].Url = @"http://apress.com/book/view/9781430229919";

            books[3] = new Book();
            books[3].Title = "Silverlight 2 Recipes";
            books[3].Author = "Jit Ghosh, Rob Cameron";
            books[3].isbn = "978-1-59059-977-8";
            books[3].Url = @"http://apress.com/book/view/9781590599778";

            return books;
        }

    }
}
