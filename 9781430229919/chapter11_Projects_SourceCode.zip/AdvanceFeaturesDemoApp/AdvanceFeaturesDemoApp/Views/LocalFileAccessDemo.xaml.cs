﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;
//added
using System.IO;
using System.Windows.Media.Imaging;

namespace AdvanceFeaturesDemoApp.Views
{
    public partial class LocalFileAccessDemo : Page
    {
      
        List<string> imageFileList = new List<string>();

        public LocalFileAccessDemo()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(LocalFileAccessDemo_Loaded);
        }

        void LocalFileAccessDemo_Loaded(object sender, RoutedEventArgs e)
        {

            // If running with elevated permissions, populate the TreeView
            if (Application.Current.HasElevatedPermissions)
            {
                string path = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);

                foreach (string dir in Directory.EnumerateDirectories(path))
                {
                    TreeViewItem item = new TreeViewItem();
                    item.Header = dir.Substring(dir.LastIndexOf('\\') + 1);
                    treeDir.Items.Add(item);
                    GetDir(dir, item.Items);
                }
              
            }
        }
        private void GetDir(string path, ItemCollection items)
        {
            foreach (string dir in Directory.EnumerateDirectories(path))
            {
                TreeViewItem item = new TreeViewItem();
                item.Header = dir.Substring(dir.LastIndexOf('\\') + 1);
                items.Add(item);
                GetDir(dir, item.Items);
            }
        }

        // Executes when the user navigates to this page.
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        
        void img_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            ImageWindow iw = new ImageWindow(((Image)sender).Source);
            iw.Show();
        }

        private void treeDir_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            // Get the path to the selected folder 
            TreeView tv = (TreeView)sender;
            string path = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);

            foreach (KeyValuePair<object, TreeViewItem> node in tv.GetSelectedPath())
                path += "\\" + node.Value.Header.ToString();

            // Remove existing items from imageFileList and ImageBox
            ImageBox.Children.Clear();
            imageFileList.Clear();   

            // Add new items to the imageFileList for processing later on
            foreach ( string  file in Directory.EnumerateFiles(path))
            {
                string name = file.ToLower();
                if (name.EndsWith(".png") || name.EndsWith(".jpg") || name.EndsWith(".jpeg"))
                    imageFileList.Add(file);
            }


            
            foreach (var item in imageFileList)
            {
                CreateThumbnail(item );
            }

            //display notification window
            NotificationWindow notify = new NotificationWindow();
            var content = new NotifyContent();
            content.Count = imageFileList.Count();
            notify.Height = content.Height;
            notify.Width = content.Width;
            notify.Content = content;
            notify.Show(2000); 
        }

        private void CreateThumbnail(string file)
        {

            using (FileStream stream = File.Open(file, FileMode.Open))
            {
                // Decode the image bits
                BitmapImage bi = null;
                                
                    bi = new BitmapImage();
                    bi.SetSource(stream);

                    Image img = new Image();
                    img.Source = bi;
                    img.Margin = new Thickness(5);
                    img.Width = 120;
                    img.MouseLeftButtonDown += img_MouseLeftButtonDown;
                    img.Stretch = Stretch.Uniform;
                    ImageBox.Children.Add(img);
            }
        }

    }
}
