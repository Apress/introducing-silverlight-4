﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace AdvanceFeaturesDemoApp.Views
{
    public partial class ImageWindow : ChildWindow
    {
        ScaleTransform zoomTransform = new ScaleTransform();
        private ImageSource imgSource;

        public ImageWindow(ImageSource source)
        {
            InitializeComponent();
            imgSource = source;
            ImageStage.RenderTransform = zoomTransform;
            this.Loaded+=new RoutedEventHandler(ImageWindow_Loaded);
            this.MouseWheel += new MouseWheelEventHandler(ImageWindow_MouseWheel);
        }

        void ImageWindow_MouseWheel(object sender, MouseWheelEventArgs e)
        {
            //Following two lines ensures that it will center zoom the image portion where cursor is
            zoomTransform.CenterX = e.GetPosition(null).X;
            zoomTransform.CenterY = e.GetPosition(null).Y;

            if (e.Delta > 0)
            {

                zoomTransform.ScaleX += 0.05;
                zoomTransform.ScaleY += 0.05;
            }
            else
            {
                zoomTransform.ScaleX -= 0.1;
                zoomTransform.ScaleY -= 0.1;
            }
        }

    void  ImageWindow_Loaded(object sender, RoutedEventArgs e)
    {
        ImageStage.Source = imgSource;
    }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
           
            zoomTransform.ScaleX = zoomTransform.ScaleY = 1;
        }
    }
}

