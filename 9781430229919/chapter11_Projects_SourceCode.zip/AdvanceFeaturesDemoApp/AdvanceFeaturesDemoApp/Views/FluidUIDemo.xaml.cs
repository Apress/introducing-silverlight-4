﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;

namespace AdvanceFeaturesDemoApp.Views
{
    public partial class FluidUIDemo : Page
    {
        public FluidUIDemo()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(FluidUIDemo_Loaded);
        }

        void FluidUIDemo_Loaded(object sender, RoutedEventArgs e)
        {
            Add.Click += new RoutedEventHandler(Add_Click);
            StringEntry.SelectionChanged += new RoutedEventHandler(StringEntry_SelectionChanged);
        }

        void StringEntry_SelectionChanged(object sender, RoutedEventArgs e)
        {
            Add.IsEnabled = !String.IsNullOrEmpty(StringEntry.Text);

        }

        void Add_Click(object sender, RoutedEventArgs e)
        {
            if (!String.IsNullOrEmpty(StringEntry.Text))
            {
                ListOfString.Items.Add(StringEntry.Text);
                StringEntry.Text = string.Empty;
            }  // end if
        }     // end event handler

        // Executes when the user navigates to this page.
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

    }
}
