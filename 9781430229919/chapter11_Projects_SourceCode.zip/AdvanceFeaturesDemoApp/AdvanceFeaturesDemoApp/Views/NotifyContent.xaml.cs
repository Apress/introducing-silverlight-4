﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
//added
using System.ComponentModel;

namespace AdvanceFeaturesDemoApp.Views
{
    public partial class NotifyContent : UserControl, INotifyPropertyChanged 
    {
        private int _count;
        public int Count 
        {
            get { return _count; }
            set { _count = value;
            if (PropertyChanged!=null)
            {
                PropertyChanged(this,new PropertyChangedEventArgs("Count"));
            }    
            }
        }

        public NotifyContent()
        {
            InitializeComponent();
            this.DataContext = this;
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
