﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;
//added

using System.Runtime.InteropServices.Automation;
// c:\Program Files (x86)\Microsoft SDKs\Silverlight\v4.0\Libraries\Client\

namespace AdvanceFeaturesDemoApp.Views
{
    public partial class COMAccessDemo : Page
    {
       
        public COMAccessDemo()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(COMAccessDemo_Loaded);
        }

        void COMAccessDemo_Loaded(object sender, RoutedEventArgs e)
        {
            BooksGrid.ItemsSource = BookData.GetBooks();
        }

        // Executes when the user navigates to this page.
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {

        }

        private void btnExportExcel_Click(object sender, RoutedEventArgs e)
        {
            // create an instance of excel
            dynamic excel = AutomationFactory.CreateObject("Excel.Application");
            // make it visible to the user.
            excel.Visible = true;  
            // add a workbook to the instance 
            dynamic workbook = excel.workbooks.Add();
            // get the active sheet
            dynamic sheet = excel.ActiveSheet; 
            dynamic cell = null;

            int i = 1;
            // iterate through our data source and populate the excel spreadsheet
            foreach (BookInfo item in BooksGrid.ItemsSource)
            {

                cell = sheet.Cells[i, 1]; // row, column
                cell.Value = item.Title;
                cell.ColumnWidth = 25;

                cell = sheet.Cells[i, 2];
                cell.Value = item.Author;

                cell = sheet.Cells[i, 3];
                cell.Value = item.isbn;


                cell = sheet.Cells[i, 4];
                cell.Value = item.Url;

                i++;
            }
        }


        private void btnExportWord_Click(object sender, RoutedEventArgs e)
        {
            // create an instance of excel
            dynamic word = AutomationFactory.CreateObject("Word.Application");
            // make it visible to the user.
            word.Visible = true;
            // add a new Document to the instance 
            dynamic wordDocument = word.Documents.Add();
            //setting up some properties for the Document
            dynamic range = wordDocument.Range(0, 0);
            dynamic table = wordDocument.Tables.Add(range, 5, 4);
            
            //some property setting on table
            table.ApplyStyleHeadingRows = true;
            table.AllowAutoFit = true;

            //setting header
            table.Cell(1, 1).Range.Text = "Title";
            table.Cell(1, 2).Range.Text = "Author";
            table.Cell(1, 3).Range.Text = "ISBN";
            table.Cell(1, 4).Range.Text = "URL";

            int j = 2;
            foreach (BookInfo item in BooksGrid.ItemsSource)
            {
                table.Cell(j, 1).Range.Text= item.Title;
                table.Cell(j, 2).Range.Text = item.Author;
                table.Cell(j, 3).Range.Text = item.isbn;
                table.Cell(j, 4).Range.Text = item.Url;
                j++;
            }

        }
    }
}


