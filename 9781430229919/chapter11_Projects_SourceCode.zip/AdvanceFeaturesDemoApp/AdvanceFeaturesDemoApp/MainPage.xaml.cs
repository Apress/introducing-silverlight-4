﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Navigation;
using System.Windows.Shapes;
//added
using System.Net.NetworkInformation;

namespace AdvanceFeaturesDemoApp
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(MainPage_Loaded);
            NetworkChange.NetworkAddressChanged += new NetworkAddressChangedEventHandler(NetworkChange_NetworkAddressChanged);
        
        }

        void NetworkChange_NetworkAddressChanged(object sender, EventArgs e)
        {
            UpdateNetworkConnectivityStatus();
        }

        void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            UpdateNetworkConnectivityStatus();
            UpdateApplicationModeStatus();

            //check to make sure the app is installed
            //if not, only show the installer
            if (App.Current.InstallState == InstallState.Installed)
            {
                btnInstall.Visibility = Visibility.Collapsed;

            }
            else
            {
                btnInstall.Visibility = Visibility.Visible;
            }

        }

        private void UpdateNetworkConnectivityStatus()
        {
            if (NetworkInterface.GetIsNetworkAvailable())
            {
                txtNWStatus.Text  ="Connected";
                txtNWStatus.Foreground = new SolidColorBrush(Colors.Cyan  );
            }
            else
            {
                txtNWStatus.Text = "Disconnected";
                txtNWStatus.Foreground = new SolidColorBrush(Colors.Red);
            }
        }

        private void UpdateApplicationModeStatus()
        {
            if (App.Current.IsRunningOutOfBrowser )
            {
                txtAppMode.Text = "Out of Browser";
                txtAppMode.Foreground = new SolidColorBrush(Colors.Yellow);
            }
            else
            {
                txtAppMode.Text = "In Browser";
                txtAppMode.Foreground = new SolidColorBrush(Colors.Yellow  );
            }
        }



        // After the Frame navigates, ensure the HyperlinkButton representing the current page is selected
        private void ContentFrame_Navigated(object sender, NavigationEventArgs e)
        {
            foreach (UIElement child in LinksStackPanel.Children)
            {
                HyperlinkButton hb = child as HyperlinkButton;
                if (hb != null && hb.NavigateUri != null)
                {
                    if (hb.NavigateUri.ToString().Equals(e.Uri.ToString()))
                    {
                        VisualStateManager.GoToState(hb, "ActiveLink", true);
                    }
                    else
                    {
                        VisualStateManager.GoToState(hb, "InactiveLink", true);
                    }
                }
            }
        }

        // If an error occurs during navigation, show an error window
        private void ContentFrame_NavigationFailed(object sender, NavigationFailedEventArgs e)
        {
            e.Handled = true;
            ChildWindow errorWin = new ErrorWindow(e.Uri);
            errorWin.Show();
        }

        private void btnCheckUpdate_Click(object sender, RoutedEventArgs e)
        {
            App.Current.CheckAndDownloadUpdateCompleted += new CheckAndDownloadUpdateCompletedEventHandler(Current_CheckAndDownloadUpdateCompleted);
            App.Current.CheckAndDownloadUpdateAsync();
        }

        void Current_CheckAndDownloadUpdateCompleted(object sender, CheckAndDownloadUpdateCompletedEventArgs e)
        {
            if (e.UpdateAvailable)
            {
                MessageBox.Show("An application update has been downloaded. " +
                    "Restart the application to run the new version.");
            }
            else if (e.Error != null && e.Error is PlatformNotSupportedException)
            {
                MessageBox.Show("An application update is available, " +
                    "but it requires a new version of Silverlight. " +
                    "Visit the application home page to upgrade.");
            }
            else
            {
                MessageBox.Show("There is no update available.");
            }

        }

        private void btnInstall_Click(object sender, RoutedEventArgs e)
        {
            App.Current.Install();
        }

        

    }
}