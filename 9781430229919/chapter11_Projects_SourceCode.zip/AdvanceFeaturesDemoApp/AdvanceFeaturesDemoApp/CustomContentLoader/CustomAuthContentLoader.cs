﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
//added
using System.Windows.Navigation;
using System.Threading;

namespace AdvanceFeaturesDemoApp.CustomContentLoader
{
    public class CustomAuthContentLoader:INavigationContentLoader 
    {
        PageResourceContentLoader Loader = new PageResourceContentLoader();

        public IAsyncResult BeginLoad(Uri targetUri, Uri currentUri, AsyncCallback userCallback, object asyncState)
        {
             AuthLoaderAsyncResult result = new AuthLoaderAsyncResult(currentUri, asyncState);

             if (targetUri.Equals(new Uri("/Views/Home.xaml", UriKind.Relative)))
             {
                 if (App.IsLoggedIn)
                 {
                     result.Content = new Home();
                 }
                 else
                 {
                     result.RedirectUri = new Uri("/LoginPage", UriKind.Relative);
                 }

                 if (userCallback != null)
                 {
                     userCallback(result);
                 }
                 return result;
             }

             return Loader.BeginLoad(targetUri, currentUri, userCallback, asyncState);
        }
        
        public LoadResult EndLoad(IAsyncResult asyncResult)
        {
            AuthLoaderAsyncResult result = asyncResult as AuthLoaderAsyncResult;

            if (result == null)
            {
                return Loader.EndLoad(asyncResult);
            }

            if (result.Content != null)
            {
                return new LoadResult(result.Content);
            }
            else
            {
                return new LoadResult(result.RedirectUri);
            }
        }

        public bool CanLoad(Uri targetUri, Uri currentUri)
        {
            if (targetUri.Equals(new Uri("/Views/Home.xaml", UriKind.Relative)))
            {
                return true;
            }

            return Loader.CanLoad(targetUri, currentUri);
        }

        public void CancelLoad(IAsyncResult asyncResult)
        {
            Loader.CancelLoad(asyncResult);
        }

        
    }

    public class AuthLoaderAsyncResult : IAsyncResult
    {
        internal Uri Uri { get; set; }
        internal Uri RedirectUri { get; set; }
        internal object Content { get; set; }

        public object AsyncState { get; set; }
        public bool IsCompleted { get; set; }

        public AuthLoaderAsyncResult(Uri uri, object asyncState)
        {
            this.AsyncState = asyncState;
            this.Uri = uri;
        }

        public WaitHandle AsyncWaitHandle
        {
            get { return null; }
        }

        public bool CompletedSynchronously
        {
            get { return false; }
        }
    }
}
