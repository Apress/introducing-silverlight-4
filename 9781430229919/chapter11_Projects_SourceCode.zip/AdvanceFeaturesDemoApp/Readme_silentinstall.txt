Silverlight Silent Install commands:
___________________________________________________________________________________
Note: The port value as specified in origin option may differ in your configuration. 
And command prompt needs to be in the same directory where XAP package is for 
successful execution of the commands.
___________________________________________________________________________________

64bit OS

Install with overwrite:
_______________________

"%ProgramFiles(x86)%\Microsoft Silverlight\sllauncher.exe" /overwrite /install:"AdvanceFeaturesDemoApp.xap" /origin:"http://localhost:2760/ClientBin/AdvanceFeaturesDemoApp.xap" /shortcut:desktop+startmenu


Emulation with overwrite:
________________________

"%ProgramFiles(x86)%\Microsoft Silverlight\sllauncher.exe"/emulate:"AdvanceFeaturesDemoApp.xap" /origin:"http://localhost:2760/ClientBin/AdvanceFeaturesDemoApp.xap" /overwrite


Uninstall:
_________
"%ProgramFiles(x86)%\Microsoft Silverlight\sllauncher.exe" /uninstall /origin:"http://localhost:2760/ClientBin/AdvanceFeaturesDemoApp.xap"



XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX


32bit OS

Install with overwrite:
_______________________

"%ProgramFiles%\Microsoft Silverlight\sllauncher.exe" /overwrite /install:"AdvanceFeaturesDemoApp.xap" /origin:"http://localhost:2760/ClientBin/AdvanceFeaturesDemoApp.xap" /shortcut:desktop+startmenu


Emulation with overwrite:
________________________

"%ProgramFiles%\Microsoft Silverlight\sllauncher.exe"/emulate:"AdvanceFeaturesDemoApp.xap" /origin:"http://localhost:2760/ClientBin/AdvanceFeaturesDemoApp.xap" /overwrite


Uninstall:
_________

"%ProgramFiles%\Microsoft Silverlight\sllauncher.exe" /uninstall /origin:"http://localhost:2760/ClientBin/AdvanceFeaturesDemoApp.xap"
