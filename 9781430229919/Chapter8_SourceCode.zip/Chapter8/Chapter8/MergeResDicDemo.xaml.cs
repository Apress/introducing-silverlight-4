﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Chapter8
{
    public partial class MergeResDicDemo : UserControl
    {
        private bool isToggle;
        public MergeResDicDemo()
        {
            InitializeComponent();
        }
        private void ToggleButton_Click(object sender, RoutedEventArgs e)
        {
            if (isToggle == false)
            {
                tbMainTitle.Style = LayoutRoot.Resources["DynamicTitle"] as Style;
                tbMainTitle.Text = "Main Title (with DynamicTitle style)";
            }
            else
            {
                tbMainTitle.Style = LayoutRoot.
                  Resources["MainTitle"] as Style;
                tbMainTitle.Text = "Main Title (with MainTitle style)";
            }

            isToggle = !isToggle;

        }
    }
}
