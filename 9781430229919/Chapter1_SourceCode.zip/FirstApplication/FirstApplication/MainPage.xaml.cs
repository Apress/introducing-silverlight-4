﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using System.IO;
using System.Windows.Media.Imaging;

namespace FirstApplication
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
            //Loaded += new RoutedEventHandler(MainPage_Loaded);
        }

        void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            //richTextArea.Drop += new DragEventHandler(richTextArea_Drop);
        
        }    

void richTextArea_Drop(object sender, DragEventArgs e)
{
    if (e.Data == null)
        return;

    IDataObject dataObject = e.Data as IDataObject;
    FileInfo[] droppedfiles = dataObject.GetData(DataFormats.FileDrop) as FileInfo[];

    foreach (FileInfo droppedfile in droppedfiles)

        if (IsCorrectImageFileType(droppedfile.Extension.Trim().ToLower()))
        {

            using (var filestream = droppedfile.OpenRead())
            {
                var imgfile = new BitmapImage();
                imgfile.SetSource(filestream);
                var img = new Image();
                img.Source = imgfile;

                InlineUIContainer rtaImg = new InlineUIContainer();
                rtaImg.Child = img;

                Paragraph inlineImg = new Paragraph();
                richTextArea.Blocks.Add(inlineImg);
                inlineImg.Inlines.Add(rtaImg);
            }
        }
        else
        {
            MessageBox.Show(droppedfile.Name + " is not valid file.");
        }
}

        private bool IsCorrectImageFileType(string fileExtension)
        {
            switch (fileExtension)
            {
                case ".jpg":
                case ".png":
                    return true;
                default: break;
            }
            return false;
        }
    }
}
