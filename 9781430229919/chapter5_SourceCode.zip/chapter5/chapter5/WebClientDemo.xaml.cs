﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using System.Windows.Resources;
using System.Windows.Media.Imaging;


namespace chapter5
{
    public partial class WebClientDemo : UserControl
    {
        private StreamResourceInfo imageArchive;

        public WebClientDemo()
        {
            InitializeComponent();

            String[] items = {"Chrysanthemum.jpg", "Desert.jpg", "Hydrangeas.jpg"};
            imageListBox.ItemsSource = items;
        }

        private void downloadButton_Click(object sender, RoutedEventArgs e)
        {
            WebClient wc = new WebClient();
            wc.OpenReadCompleted +=
                     new OpenReadCompletedEventHandler(wc_OpenReadCompleted);
            wc.DownloadProgressChanged +=
                    new DownloadProgressChangedEventHandler(wc_DownloadProgressChanged);
            wc.OpenReadAsync(new Uri("/ImageBrowser/renaissance.zip", UriKind.Relative));
        }

        private void wc_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
        {
            
            if ((e.Error == null) && (e.Cancelled == false))
            {
                imageListBox.Visibility = Visibility.Visible;
                imageArchive = new StreamResourceInfo(e.Result, null);
            }
        }

        private void wc_DownloadProgressChanged(object sender,
                                                 DownloadProgressChangedEventArgs e)
        {
            progressTextBox.Text = e.ProgressPercentage + "%";
        }

        private void imageListBox_SelectionChanged(object sender,
SelectionChangedEventArgs e)
        {
            BitmapImage bitmapImageSource = new BitmapImage();
            StreamResourceInfo imageResourceInfo =
                Application.GetResourceStream(imageArchive, new
        Uri(imageListBox.SelectedItem.ToString(),
         UriKind.Relative));
            bitmapImageSource.SetSource(imageResourceInfo.Stream);
            image.Source = bitmapImageSource;
        }


    }
}
