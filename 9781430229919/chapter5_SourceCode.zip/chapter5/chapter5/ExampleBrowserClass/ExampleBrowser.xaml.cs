﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace chapter5.ExampleBrowserClass
{
    public partial class ExampleBrowser : UserControl
    {
        ExampleItem[] exitems = new ExampleItem[2];

        public ExampleBrowser()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(ExampleBrowser_Loaded);
            //initializing the items
            for (int i = 0; i < 2; i++)
            {
                exitems[i] = new ExampleItem();
            }
        }

        void ExampleBrowser_Loaded(object sender, RoutedEventArgs e)
        {
            CreateItems();
            foreach (var item in exitems )
            {
                TreeViewItem ti = new TreeViewItem();
                ti.Header = item.ExampleName;
                ExampleMenu.Items.Add(ti);
               
            } 
               
            //ExampleMenu.ItemsSource = exitems;
        }

        void CreateItems()
        {
            exitems[0].ExampleName = "Calling WCF service and Falut handling";
            exitems[0].ExamplePage = new MainPage ();

            exitems[1].ExampleName = "Downloading with WebClient";
            exitems[1].ExamplePage = new WebClientDemo ();

        }

        private void ExampleMenu_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            TreeViewItem tvi = ExampleMenu.SelectedItem as TreeViewItem ;
            string currentItem = tvi.Header.ToString();
            foreach (var item in exitems )
            {
                if (item.ExampleName == currentItem)
                {
                    ExampleStage.Child = item.ExamplePage;
                    break;
                }
                
            }
        }
    }
}
