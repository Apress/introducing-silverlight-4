﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace chapter5.Web
{
    public class BookInfo
    {
        public string Title;
        public string Author;
        public string ISBN;
        public List<string> Chapters;
  }
}
