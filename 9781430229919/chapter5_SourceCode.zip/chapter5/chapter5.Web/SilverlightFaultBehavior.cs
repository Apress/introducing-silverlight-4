﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
//added
using System.ServiceModel.Dispatcher;
using System.ServiceModel.Channels;
using System.ServiceModel.Configuration;
using System.ServiceModel.Description;
using System.ServiceModel;

namespace chapter5.Web
{
    public class SilverlightFaultBehavior : BehaviorExtensionElement, IEndpointBehavior, IServiceBehavior
    {
        public override Type BehaviorType
        {
            get { return (typeof(SilverlightFaultBehavior)); }
        }

        protected override object CreateBehavior()
        {
            return (new SilverlightFaultBehavior());
        }

        #region IEndpointBehavior Members

        public void ApplyDispatchBehavior(ServiceEndpoint endpoint,
                 System.ServiceModel.Dispatcher.EndpointDispatcher
                 endpointDispatcher)
        {
            SilverlightFaultProcessor processor =
                 new SilverlightFaultProcessor();

            endpointDispatcher.DispatchRuntime.
                MessageInspectors.Add(processor);
        }
        //Following methods are stubs and not relavant 
        public void AddBindingParameters(ServiceEndpoint endpoint, BindingParameterCollection bindingParameters)
        {

        }

        public void ApplyClientBehavior(ServiceEndpoint endpoint, ClientRuntime clientRuntime)
        {

        }

        public void Validate(ServiceEndpoint endpoint)
        {
        }

        #endregion

        #region IServiceBehavior Members
        //Following methods are stubs and not relavant
        public void AddBindingParameters(ServiceDescription serviceDescription, ServiceHostBase serviceHostBase, System.Collections.ObjectModel.Collection<ServiceEndpoint> endpoints, BindingParameterCollection bindingParameters)
        {

        }

        public void ApplyDispatchBehavior(ServiceDescription serviceDescription, ServiceHostBase serviceHostBase)
        {

        }

        public void Validate(ServiceDescription serviceDescription, ServiceHostBase serviceHostBase)
        {

        }
        #endregion

        public class SilverlightFaultProcessor : IDispatchMessageInspector
        {
            #region IDispatchMessageInspector Members

            public object AfterReceiveRequest(
                ref System.ServiceModel.Channels.Message request,
                System.ServiceModel.IClientChannel channel,
                System.ServiceModel.InstanceContext instanceContext)
            {
                return (null);
            }

            public void BeforeSendReply(
              ref System.ServiceModel.Channels.Message reply,
              object correlationState)
            {
                if (reply.IsFault)
                {
                    // If it's a fault, change the status code 
                    // to 200 so Silverlight can receive the 
                    // details of the fault

                    HttpResponseMessageProperty responseProperty =
                       new HttpResponseMessageProperty();

                    responseProperty.StatusCode =
                            System.Net.HttpStatusCode.OK;

                    reply.Properties[HttpResponseMessageProperty.Name]
                          = responseProperty;
                }
            }

            #endregion
        }




    }
}