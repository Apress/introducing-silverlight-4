﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace chapter9.ExampleBrowserClass
{
    public partial class ExampleBrowser : UserControl
    {
        ExampleItem[] exitems = new ExampleItem[15];

        public ExampleBrowser()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(ExampleBrowser_Loaded);
            //initializing the items
            for (int i = 0; i < 15; i++)
            {
                exitems[i] = new ExampleItem();
            }
        }

        void ExampleBrowser_Loaded(object sender, RoutedEventArgs e)
        {
            CreateItems();
            foreach (var item in exitems )
            {
                TreeViewItem ti = new TreeViewItem();
                ti.Header = item.ExampleName;
                ExampleMenu.Items.Add(ti);
               
            } 
               
            //ExampleMenu.ItemsSource = exitems;
        }

        void CreateItems()
        {
            exitems[0].ExampleName = "Simple Geometries";
            exitems[0].ExamplePage = new SimpleGeometriesDemo();

            exitems[1].ExampleName = "Path Geometries";
            exitems[1].ExamplePage = new PathGeometriesDemo ();

            exitems[2].ExampleName = "Clipping with Geometry";
            exitems[2].ExamplePage = new ClippingDemo ();

            exitems[3].ExampleName = "Using Shapes";
            exitems[3].ExamplePage = new ShapesDemo ();

            exitems[4].ExampleName = "Path";
            exitems[4].ExamplePage = new PathDemo ();

            exitems[5].ExampleName = "Transforms";
            exitems[5].ExamplePage = new TransformsDemo ();

            exitems[6].ExampleName = "Linear Transforms";
            exitems[6].ExamplePage = new LinearTransformsDemo ();
            
            exitems[7].ExampleName = "Multiple Transform";
            exitems[7].ExamplePage = new MultipleTransformsDemo ();

            exitems[8].ExampleName = "CompositeTransform";
            exitems[8].ExamplePage = new CompositeTransformDemo ();

            exitems[9].ExampleName = "Perspective Transform";
            exitems[9].ExamplePage = new PlanetProjectionDemo ();

            exitems[10].ExampleName = "Pixel Shadders";
            exitems[10].ExamplePage = new PixelShadderDemo();

            exitems[11].ExampleName = "Brushes";
            exitems[11].ExamplePage = new BrushesDemo ();

            exitems[12].ExampleName = "ImageBrush";
            exitems[12].ExamplePage = new ImageBrushDemo();

            exitems[13].ExampleName = "VideoBrush";
            exitems[13].ExamplePage = new VideoBrushDemo();

            exitems[14].ExampleName = "Transparency and OpacityMask";
            exitems[14].ExamplePage = new OpacityMaskDemo ();

    

        }

        private void ExampleMenu_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            TreeViewItem tvi = ExampleMenu.SelectedItem as TreeViewItem ;
            string currentItem = tvi.Header.ToString();
            foreach (var item in exitems )
            {
                if (item.ExampleName == currentItem)
                {
                    ExampleStage.Child = item.ExamplePage;
                    break;
                }
                
            }
        }
    }
}
