﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
//added
using System.ComponentModel.DataAnnotations;

namespace chapter3
{
    public class Child
    {
        [Display (Name="Name of the Child")]
        public string name { get; set; }
        [Display(Name = "Height of the Child")]
        public string height { get; set; }
        [Display(Name = "Gender of the Child")]
        public string gender { get; set; }
    }
}
