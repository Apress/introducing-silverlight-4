﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
//added
using System.IO;
namespace chapter3
{
    public partial class SaveFileDialogDemo : UserControl
    {
        public SaveFileDialogDemo()
        {
            InitializeComponent();
        }
        private void SaveFileButton_Click(object sender,RoutedEventArgs e)
        {
            
            SaveFileDialog filesavedialog = new SaveFileDialog();
            //Set Save File Dialog box FileType Filter
            filesavedialog.Filter = "Text files|*.txt";
            //Show standard Save File Dialog
            bool? result = filesavedialog.ShowDialog();
            //Save entered text as a text file
            if (result == true)
            {
                using (StreamWriter writer = new
                StreamWriter(filesavedialog.OpenFile()))
                {
                    writer.Write(SaveText.Text);
                    writer.Close();
                }
            }
        }

    }
}
