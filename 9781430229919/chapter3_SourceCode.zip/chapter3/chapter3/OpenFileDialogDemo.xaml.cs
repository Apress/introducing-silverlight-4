﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
//added
using System.IO;

namespace chapter3
{
    public partial class OpenFileDialogDemo : UserControl
    {
        private string contents;
        public OpenFileDialogDemo()
        {
            InitializeComponent();

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "Text files|*.txt";

            dlg.Multiselect = false;

            if ((bool)dlg.ShowDialog())
            {
                using (StreamReader reader = new StreamReader(dlg.File.OpenRead()))
                
                {
                    txtContents.Text = reader.ReadToEnd();
                    reader.Close();
                }
                

            }
        }
    }
}
