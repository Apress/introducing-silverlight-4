﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace chapter3
{
    public partial class AutoCompleteBoxDemo : UserControl
    {
        public AutoCompleteBoxDemo()
        {
            InitializeComponent();

            List<string> stateList = new List<string>();
            stateList.Add("Alabama");
            stateList.Add("Alaska");
            stateList.Add("American Somoa");
            stateList.Add("Arizona");
            stateList.Add("Arknasas");
            stateList.Add("Wisconsin");
            stateList.Add("Wyoming");
            stateSelection.ItemsSource = stateList;
        }


    }
}
