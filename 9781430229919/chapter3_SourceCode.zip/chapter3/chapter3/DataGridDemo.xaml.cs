﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace chapter3
{
    public partial class DataGridDemo : UserControl
    {
               public DataGridDemo()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(DataGridDemo_Loaded);
        }

        void DataGridDemo_Loaded(object sender, RoutedEventArgs e)
        {
            Child[] children = new Child[3];

            children[0] = new Child();
            children[0].name = "Gyan Ghoda";
            children[0].height = "4.5''";
            children[0].gender = "M";

            children[1] = new Child();
            children[1].name = "Anand Ghoda";
            children[1].height = "30''";
            children[1].gender = "M";

            children[2] = new Child();
            children[2].name = "Keshvi Nanavaty";
            children[2].height = "30''";
            children[2].gender = "F";

            DataGrid1.ItemsSource = children;
        }
    }
}
