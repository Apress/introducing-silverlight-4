﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace chapter3.ExampleBrowserClass
{
    public partial class ExampleBrowser : UserControl
    {
        ExampleItem[] exitems = new ExampleItem[35];

        public ExampleBrowser()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(ExampleBrowser_Loaded);
            //initializing the items
            for (int i = 0; i < 35; i++)
            {
                exitems[i] = new ExampleItem();
            }
        }

        void ExampleBrowser_Loaded(object sender, RoutedEventArgs e)
        {
            CreateItems();
            foreach (var item in exitems )
            {
                TreeViewItem ti = new TreeViewItem();
                ti.Header = item.ExampleName;
                ExampleMenu.Items.Add(ti);
               
            } 
               
            //ExampleMenu.ItemsSource = exitems;
        }

        void CreateItems()
        {
            exitems[0].ExampleName = "Canvas";
            exitems[0].ExamplePage = new CanvasDemo();

            exitems[1].ExampleName = "StackPanel";
            exitems[1].ExamplePage = new StackPanelDemo();

            exitems[2].ExampleName = "Grid";
            exitems[2].ExamplePage = new GridDemo();

            exitems[3].ExampleName = "Star Sizing Grid";
            exitems[3].ExamplePage = new StarSizingDemo();

            exitems[4].ExampleName = "DockPanel";
            exitems[4].ExamplePage = new DockPanelDemo();

            exitems[5].ExampleName = "TabControl";
            exitems[5].ExamplePage =  new TabControlDemo();

            exitems[6].ExampleName = "Viewbox";
            exitems[6].ExamplePage =  new ViewboxDemo();

            exitems[7].ExampleName = "Buttons";
            exitems[7].ExamplePage = new ButtonsDemo();

            exitems[8].ExampleName = "ItemsControl";
            exitems[8].ExamplePage = new ItemsControlDemo();

            exitems[9].ExampleName = "HeaderedItemsControl";
            exitems[9].ExamplePage = new HeaderedItemsControlDemo();

            exitems[10].ExampleName = "HeaderedContentControl";
            exitems[10].ExamplePage = new HeaderedContentControlDemo();

            exitems[11].ExampleName = "TextBlock";
            exitems[11].ExamplePage = new TextBlockDemo();

            exitems[12].ExampleName = "TextBox";
            exitems[12].ExamplePage = new TextBoxDemo();

            exitems[13].ExampleName = "RichTextArea";
            exitems[13].ExamplePage = new RichTextAreaDemo();

            exitems[14].ExampleName = "PasswordBox";
            exitems[14].ExamplePage = new PasswordBoxDemo();

            exitems[15].ExampleName = "AutoCompleteBox";
            exitems[15].ExamplePage = new AutoCompleteBoxDemo();

            exitems[16].ExampleName = "DataGrid";
            exitems[16].ExamplePage = new DataGridDemo();

            exitems[17].ExampleName = "DataForm";
            exitems[17].ExamplePage = new DataFormDemo();

            exitems[18].ExampleName = "Label";
            exitems[18].ExamplePage = new LabelDemo();

            exitems[19].ExampleName = "TreeView";
            exitems[19].ExamplePage = new TreeViewDemo();

            exitems[20].ExampleName = "Border";
            exitems[20].ExamplePage = new BorderDemo();

            exitems[21].ExampleName = "GridSplitter";
            exitems[21].ExamplePage = new GridSplitterDemo();

            exitems[22].ExampleName = "Calendar and DatePicker";
            exitems[22].ExamplePage = new CalendarDatePickerDemo();

            exitems[23].ExampleName = "ScrollBar";
            exitems[23].ExamplePage = new ScrollBarDemo();

            exitems[24].ExampleName = "Slider";
            exitems[24].ExamplePage = new SliderDemo();

            exitems[25].ExampleName = "ProgressBar";
            exitems[25].ExamplePage = new ProgressBarDemo();

            exitems[26].ExampleName = "ScrollViewer";
            exitems[26].ExamplePage = new ScrollViewerDemo();

            exitems[27].ExampleName = "OpenFileDialog";
            exitems[27].ExamplePage = new OpenFileDialogDemo();

            exitems[28].ExampleName = "SaveFileDialog";
            exitems[28].ExamplePage = new SaveFileDialogDemo();

            exitems[29].ExampleName = "ChildWindow";
            exitems[29].ExamplePage = new ChildWindowDemo();

            exitems[30].ExampleName = "ToolTipService";
            exitems[30].ExamplePage = new ToolTipServiceDemo();

            exitems[31].ExampleName = "PopUp";
            exitems[31].ExamplePage = new PopUpDemo();

            exitems[32].ExampleName = "WrapPanel";
            exitems[32].ExamplePage = new WrapPanelDemo();

            exitems[33].ExampleName = "Image";
            exitems[33].ExamplePage = new ImageDemo();

            exitems[34].ExampleName = "InkPresenter";
            exitems[34].ExamplePage = new InkPresenterDemo();

        }

        private void ExampleMenu_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            TreeViewItem tvi = ExampleMenu.SelectedItem as TreeViewItem ;
            string currentItem = tvi.Header.ToString();
            foreach (var item in exitems )
            {
                if (item.ExampleName == currentItem)
                {
                    ExampleStage.Child = item.ExamplePage;
                    break;
                }
                
            }
        }
    }
}
