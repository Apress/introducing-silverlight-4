﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Ink;

namespace chapter3
{
    public partial class InkPresenterDemo : UserControl
    {
        Stroke newStroke;

        public InkPresenterDemo()
        {
            InitializeComponent();
        }

        void inkPad_MouseLeftButtonDown(object sender, MouseEventArgs e)
        {
            inkPad.CaptureMouse();
            newStroke = new System.Windows.Ink.Stroke();
            newStroke.StylusPoints.Add(e.StylusDevice.GetStylusPoints(inkPad));
            inkPad.Strokes.Add(newStroke);
        }
        void inkPad_MouseMove(object sender, MouseEventArgs e)
        {
            if (newStroke != null)
            {
                newStroke.StylusPoints.Add(e.StylusDevice.GetStylusPoints(inkPad));
            }
        }
        void inkPad_LostMouseCapture(object sender, MouseEventArgs e)
        {
            newStroke = null;
            inkPad.ReleaseMouseCapture();
        }
    }
}
