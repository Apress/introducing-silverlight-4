Please add following named images to "res" folder before running this project:

1.jpg
2.jpg
3.jpg
4.jpg
5.jpg
Buddy.png

