﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace chapter3
{
    public partial class LabelDemo : UserControl
    {
        public LabelDemo()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(LabelDemo_Loaded);
        }

        void LabelDemo_Loaded(object sender, RoutedEventArgs e)
        {
            Child child1 = new Child();
            child1.name = "Anand Ghoda";
            child1.height = "30''";
            child1.gender = "M";        
            LayoutRoot.DataContext= child1 ;   
        }
        
    }
}
