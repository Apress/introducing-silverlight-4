﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using System.Windows.Media.Imaging;

namespace MediaIntegration
{
    public partial class WebCameraAndMicroPhoneIntegration : UserControl
    {
        TransformGroup imageTransform;
        LinearGradientBrush lnrGradBrush;
        
        CaptureSource CapturedSource;

        public WebCameraAndMicroPhoneIntegration()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(WebCameraAndMicroPhoneIntegration_Loaded);
        }

        void WebCameraAndMicroPhoneIntegration_Loaded(object sender, RoutedEventArgs e)
        {
            DefineImageTransform();
            DefineOpacityMask();

            CapturedSource = new CaptureSource();            
        }

        private void CaptureVideo_Click(object sender, RoutedEventArgs e)
        {
            if (CapturedSource != null)
            {
                CapturedSource.Stop();

                CapturedSource.VideoCaptureDevice = CaptureDeviceConfiguration.GetDefaultVideoCaptureDevice();
                CapturedSource.AudioCaptureDevice = CaptureDeviceConfiguration.GetDefaultAudioCaptureDevice();

                VideoBrush vidBrush = new VideoBrush();
                vidBrush.SetSource(CapturedSource);
                sourceVideo.Fill = vidBrush;

                if (CaptureDeviceConfiguration.AllowedDeviceAccess || CaptureDeviceConfiguration.RequestDeviceAccess())
                {
                    CapturedSource.Start();

                    CapturedSource.CaptureImageCompleted +=
                      new EventHandler<CaptureImageCompletedEventArgs>((s, args) =>
                      {
                          Image thumbImage = new Image();
                          thumbImage.Height = 90;
                          thumbImage.Margin = new Thickness(2, 0, 2, 0);
                          thumbImage.Source = args.Result;

                          Image reflectedImage = new Image();
                          reflectedImage.Height = 90;
                          reflectedImage.Margin = new Thickness(2, 0, 2, 0);
                          reflectedImage.Source = args.Result;
                          reflectedImage.OpacityMask = lnrGradBrush;
                          reflectedImage.RenderTransform = imageTransform;

                          StackPanel sp = new StackPanel();

                          sp.Children.Add(thumbImage);
                          sp.Children.Add(reflectedImage);

                          thumbsPanel.Children.Add(sp);

                          scrollArea.UpdateLayout();
                          double scrollPos = thumbsPanel.ActualWidth;
                          scrollArea.ScrollToHorizontalOffset(scrollPos);
                      });
                }
            }
        }

        private void sourceVideo_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

            if (CapturedSource.State == CaptureState.Started && CapturedSource != null)
            {
                //capture a still image
                CapturedSource.CaptureImageAsync();
                

                //CapturedSource.AsyncCaptureImage ((snapImage) =>
                //{
                //    Image thumbImage = new Image();
                //    thumbImage.Height = 90;
                //    thumbImage.Margin = new Thickness(2, 0, 2, 0);
                //    thumbImage.Source = snapImage;

                //    Image reflectedImage = new Image();
                //    reflectedImage.Height = 90;
                //    reflectedImage.Margin = new Thickness(2, 0, 2, 0);
                //    reflectedImage.Source = snapImage;
                //    reflectedImage.OpacityMask = lnrGradBrush;
                //    reflectedImage.RenderTransform = imageTransform;

                //    StackPanel sp = new StackPanel();

                //    sp.Children.Add(thumbImage);
                //    sp.Children.Add(reflectedImage);

                //    thumbsPanel.Children.Add(sp);

                //    scrollArea.UpdateLayout();
                //    double scrollPos = thumbsPanel.ActualWidth;
                //    scrollArea.ScrollToHorizontalOffset(scrollPos);
                //});
            }

        }

        private void DefineImageTransform()
        {
            imageTransform = new TransformGroup();

            TranslateTransform TranlateImageTransform = new TranslateTransform();
            TranlateImageTransform.Y = -90;

            ScaleTransform ScaleImageTransform = new ScaleTransform();
            ScaleImageTransform.ScaleY = -1;

            imageTransform.Children.Add(TranlateImageTransform);
            imageTransform.Children.Add(ScaleImageTransform);
        }

        private void DefineOpacityMask()
        {           
            lnrGradBrush = new LinearGradientBrush();

            lnrGradBrush.StartPoint = new Point(0.5, 0);
            lnrGradBrush.EndPoint = new Point(0.5, 1);
            lnrGradBrush.MappingMode = BrushMappingMode.RelativeToBoundingBox;

            GradientStop grdStop1 = new GradientStop();
            grdStop1.Color = Color.FromArgb(100,0,0,0);
            grdStop1.Offset = 0.6;

            GradientStop grdStop2 = new GradientStop();
            grdStop2.Color = Color.FromArgb(10, 233, 217, 217);
            grdStop2.Offset = 0.3;

            lnrGradBrush.GradientStops.Add(grdStop2);
            lnrGradBrush.GradientStops.Add(grdStop1);
        }


        private void VideoStop_Click(object sender, RoutedEventArgs e)
        {
            if (CapturedSource != null)
            {
                CapturedSource.Stop();
            }

        }

    }
}
