﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using System.Windows.Media.Imaging;

namespace MediaIntegration
{
    public partial class WriteableBitmapDemonstrationwithVideoPlayer : UserControl
    {
        TransformGroup imageTransform;
        LinearGradientBrush lnrGradBrush;

        public WriteableBitmapDemonstrationwithVideoPlayer()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(WriteableBitmapDemonstrationwithVideoPlayer_Loaded);
        }

        void WriteableBitmapDemonstrationwithVideoPlayer_Loaded(object sender, RoutedEventArgs e)
        {
            //Applying Cache and Frame Rate Counter visualization
            //Application.Current.Host.Settings.EnableCacheVisualization = true;
            //Application.Current.Host.Settings.EnableFrameRateCounter = true;
            

            DefineImageTransform();
            DefineOpacityMask();
        }

        private void sourceVideo_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            WriteableBitmap snapShot = new WriteableBitmap(sourceVideo, null);
            Image thumbImage = new Image();
            thumbImage.Height = 90;
            thumbImage.Margin = new Thickness(2, 0, 2, 0);
            thumbImage.Source = snapShot;

            WriteableBitmap reflectedShot = new WriteableBitmap(sourceVideo, imageTransform);
            Image reflectedImage = new Image();
            reflectedImage.Height = 90;
            reflectedImage.Margin = new Thickness(2, 0, 2, 0);
            reflectedImage.Source = reflectedShot;
            reflectedImage.OpacityMask = lnrGradBrush;

            StackPanel sp = new StackPanel();

            sp.Children.Add(thumbImage);
            sp.Children.Add(reflectedImage);

            thumbsPanel.Children.Add(sp);

            scrollArea.UpdateLayout();
            double scrollPos = thumbsPanel.ActualWidth;
            scrollArea.ScrollToHorizontalOffset(scrollPos);
        }

        private void DefineImageTransform()
        {
            imageTransform = new TransformGroup();

            //TranslateTransform TranlateImageTransform = new TranslateTransform();
            //TranlateImageTransform.Y = -256;

            //ScaleTransform ScaleImageTransform = new ScaleTransform();
            //ScaleImageTransform.ScaleY = -1;

            //imageTransform.Children.Add(TranlateImageTransform);
            //imageTransform.Children.Add(ScaleImageTransform);
        }

        private void DefineOpacityMask()
        {           
            lnrGradBrush = new LinearGradientBrush();

            lnrGradBrush.StartPoint = new Point(0.5, 0);
            lnrGradBrush.EndPoint = new Point(0.5, 1);
            lnrGradBrush.MappingMode = BrushMappingMode.RelativeToBoundingBox;

            GradientStop grdStop1 = new GradientStop();
            grdStop1.Color = Color.FromArgb(10, 233, 217, 217);
            grdStop1.Offset = 0.6;

            GradientStop grdStop2 = new GradientStop();
            grdStop2.Color = Color.FromArgb(100, 0, 0, 0);
            grdStop2.Offset = 0.3;

            lnrGradBrush.GradientStops.Add(grdStop1);
            lnrGradBrush.GradientStops.Add(grdStop2);
        }

        private void VideoPlay_Click(object sender, RoutedEventArgs e)
        {
            if (sourceVideo.CurrentState != MediaElementState.Opening || sourceVideo.CurrentState == MediaElementState.Stopped || sourceVideo.CurrentState == MediaElementState.Paused)
                sourceVideo.Play();
        }

        private void VideoPause_Click(object sender, RoutedEventArgs e)
        {
            if (sourceVideo.CurrentState == MediaElementState.Playing)
                sourceVideo.Pause();
        }

        private void VideoStop_Click(object sender, RoutedEventArgs e)
        {
            if (sourceVideo.CurrentState == MediaElementState.Playing || sourceVideo.CurrentState == MediaElementState.Paused)
                sourceVideo.Stop();
        }

        private void sourceVideo_MediaEnded(object sender, RoutedEventArgs e)
        {
            sourceVideo.Stop();
            if (ContinuousPlay.IsChecked == true)
                sourceVideo.Play();
        }
    }
}
