﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace chapter7
{
    public partial class ClipDemo : UserControl
    {
        public ClipDemo()
        {
            InitializeComponent();
        }

        private void btnCopy_Click(object sender, RoutedEventArgs e)
        {
            if (!String.IsNullOrEmpty(richTextArea.Selection.Text))
                Clipboard.SetText(richTextArea.Selection.Text);
            else
                MessageBox.Show("No Text is selected to copy");            
        }

        private void btnPaste_Click(object sender, RoutedEventArgs e)
        {
            if (Clipboard.ContainsText())
            {
                Run insertText = new Run();
                insertText.Text = Clipboard.GetText();
                richTextArea.Selection.Insert(insertText);
            }
            else
                MessageBox.Show("No Text available to paste");
        }

    }
}
