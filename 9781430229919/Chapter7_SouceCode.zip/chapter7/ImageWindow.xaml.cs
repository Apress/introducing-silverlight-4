﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
//added
using System.Windows.Controls.Primitives;
using System.Windows.Printing;
using System.Windows.Data;
namespace chapter7
{
    public partial class ImageWindow : ChildWindow
    {
        ScaleTransform zoomTransform = new ScaleTransform();
        private ImageSource imgSource {get; set;}
        Popup contextMenu = new Popup();

        public ImageWindow(ImageSource source)
        {
            InitializeComponent();
            imgSource = source;
            ImageStage.RenderTransform = zoomTransform;
            this.Loaded+=new RoutedEventHandler(ImageWindow_Loaded);
            this.MouseWheel += new MouseWheelEventHandler(ImageWindow_MouseWheel);
        }

        void ImageWindow_MouseWheel(object sender, MouseWheelEventArgs e)
        {
            //Following two lines ensures that it will center zoom the image portion where cursor is
            zoomTransform.CenterX = e.GetPosition(null).X;
            zoomTransform.CenterY = e.GetPosition(null).Y;

            if (e.Delta > 0)
            {

                zoomTransform.ScaleX += 0.05;
                zoomTransform.ScaleY += 0.05;
            }
            else
            {
                zoomTransform.ScaleX -= 0.1;
                zoomTransform.ScaleY -= 0.1;
            }
        }

    void  ImageWindow_Loaded(object sender, RoutedEventArgs e)
    {
        ImageStage.Source = imgSource;
    }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
           
            zoomTransform.ScaleX = zoomTransform.ScaleY = 1;
        }

        private void LayoutRoot_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            e.Handled = true;
        }

        private void LayoutRoot_MouseRightButtonUp(object sender, MouseButtonEventArgs e)
        {
            Border border = new Border();
            border.BorderBrush = new SolidColorBrush(Colors.Green);
            border.BorderThickness = new Thickness(3);
            border.Background = new SolidColorBrush(Colors.White);

            StackPanel panel1 = new StackPanel();
            panel1.Background = new SolidColorBrush(Colors.LightGray);

            //Print Screen Button
            Button printscreenbutton = new Button();
            printscreenbutton.Content = "Print Screen";
            printscreenbutton.Width = 100;
            printscreenbutton.Margin = new Thickness(3);
            //Click event to provide print functionality
            printscreenbutton.Click += new RoutedEventHandler(printscreen_Click);

            //Print Image Button
            Button printimagebutton = new Button();
            printimagebutton.Content = "Print Image";
            printimagebutton.Width = 100;
            printimagebutton.Margin = new Thickness(3);
            //Click event to provide print functionality
            printimagebutton.Click += new RoutedEventHandler(printimage_Click);

            //Custom Print Button
            Button printcustombutton = new Button();
            printcustombutton.Content = "Custom Print";
            printcustombutton.Width = 100;
            printcustombutton.Margin = new Thickness(3);
            //Click event to provide print functionality
            printcustombutton.Click += new RoutedEventHandler(printcustom_Click);

            panel1.Children.Add(printscreenbutton);
            panel1.Children.Add(printimagebutton);
            panel1.Children.Add(printcustombutton);

            border.Child = panel1;

            contextMenu.Child = border;
            //set display location to current cursor
            contextMenu.VerticalOffset = e.GetPosition(null).Y;
            contextMenu.HorizontalOffset = e.GetPosition(null).X;
            //show the popup
            contextMenu.IsOpen = true;
        }

        private void LayoutRoot_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            contextMenu.IsOpen = false;
        }

        private void ImageStage_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            e.Handled = true;
        }

        private void ImageStage_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            contextMenu.IsOpen = false;
        }

        private void printscreen_Click(object sender, RoutedEventArgs e)
        {
            contextMenu.IsOpen = false;
            PrintDocument pdoc = new PrintDocument();
            // Set the printable area
            pdoc.PrintPage += (s, args) =>
            {
                args.PageVisual = LayoutRoot;
            };
            // Print the document
            pdoc.Print("Printing Application Screen");
        }

        private void printimage_Click(object sender, RoutedEventArgs e)
        {
            contextMenu.IsOpen = false;
            PrintDocument pdoc = new PrintDocument();
            // Set the printable area
            pdoc.PrintPage += (s, args) =>
            {
                args.PageVisual = ImageStage;
            };
            // Print the document
            pdoc.Print("Printing Image");
        }

        private void printcustom_Click(object sender, RoutedEventArgs e)
        {
            StackPanel panel1 = new StackPanel();
            panel1.Background = new SolidColorBrush(Colors.White);

            TextBlock textblock = new TextBlock();

            textblock.Text = "Custom Print Example";
            textblock.FontWeight = FontWeights.Bold;
            textblock.FontSize = 12;

            Image image = new Image();
            image.Source = imgSource;
            image.Width = 300;
            image.Height = 300;

            Point point = new Point(150, 150);
            EllipseGeometry eg = new EllipseGeometry();
            eg.RadiusX = 100;
            eg.RadiusY = 100;
            eg.Center = point;

            image.Clip = eg;

            panel1.Children.Add(textblock);
            panel1.Children.Add(image);

            contextMenu.IsOpen = false;
            PrintDocument pdoc = new PrintDocument();
            // Set the printable area
            pdoc.PrintPage += (s, args) =>
            {
                args.PageVisual = panel1;
            };
            // Print the document
            pdoc.Print("Custom Printing");
        }
    }
}

