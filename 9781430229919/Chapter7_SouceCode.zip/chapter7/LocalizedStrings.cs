﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
//added
using System.ComponentModel;

namespace chapter7
{
    public class LocalizedStrings:INotifyPropertyChanged 
    {
        public LocalizedStrings()
        {
        }

        private static Resources.Strings resource = new Resources.Strings();

        public Resources.Strings Resource {
            get
            {
                return resource;

           
            }
            set
            {
                resource = value;
             if (this.PropertyChanged!=null )
            {
                PropertyChanged(this, new PropertyChangedEventArgs("Resource"));
            }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
