﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using System.Globalization;

namespace chapter7
{
    public partial class CultureInfoDemo : UserControl
    {
        public CultureInfoDemo()
        {
            InitializeComponent();
            GetCultureInfo();
        }

        private void GetCultureInfo()
        {
            string s;
            
            CultureInfo cul = CultureInfo.CurrentCulture;

            s = "Current Culture Information " + cul.Name + "\n";
            s += String.Format("   Name: {0}\n", cul.Name);
            s += String.Format("   Display Name: {0}\n", cul.DisplayName);
            s += String.Format("   Native Name: {0}\n", cul.NativeName);
            s += String.Format("   English Name: {0}\n", cul.EnglishName);
            s += String.Format("   Parent Culture Name: {0}\n", cul.Parent.Name);
            s += String.Format("   Calendar: {0}\n", cul.Calendar.ToString());
            s += String.Format("   Is read-only: {0}\n", cul.Calendar.IsReadOnly);

            CultureInfo culUI = CultureInfo.CurrentUICulture;

            s += "\nCurrent UI Culture Information " + culUI.Name + "\n";
            s += String.Format("   Name: {0}\n", culUI.Name);
            s += String.Format("   Display Name: {0}\n", culUI.DisplayName);
            s += String.Format("   Native Name: {0}\n", culUI.NativeName);
            s += String.Format("   English Name: {0}\n", culUI.EnglishName);
            s += String.Format("   Parent Culture Name: {0}\n", culUI.Parent.Name);
            s += String.Format("   Calendar: {0}\n", culUI.Calendar.ToString());
            s += String.Format("   Is read-only: {0}\n", culUI.Calendar.IsReadOnly);

            CultureInfo culInvariant = CultureInfo.CurrentUICulture;

            s += "\nCurrent Invariant Culture Information " + culInvariant.Name + "\n";
            s += String.Format("   Name: {0}\n", culInvariant.Name);
            s += String.Format("   Display Name: {0}\n", culInvariant.DisplayName);
            s += String.Format("   Native Name: {0}\n", culInvariant.NativeName);
            s += String.Format("   English Name: {0}\n", culInvariant.EnglishName);
            s += String.Format("   Parent Culture Name: {0}\n", culInvariant.Parent.Name);
            s += String.Format("   Calendar: {0}\n", culInvariant.Calendar.ToString());
            s += String.Format("   Is read-only: {0}\n", culInvariant.Calendar.IsReadOnly);

            current.Text = s;
        }

       
    }
}
