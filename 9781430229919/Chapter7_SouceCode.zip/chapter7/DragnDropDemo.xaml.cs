﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
//added
using System.IO;
using System.Windows.Media.Imaging;
using System.Windows.Controls.Primitives;
using System.Windows.Printing;
using System.Threading;
namespace chapter7
{
    public partial class DragnDropDemo : UserControl
    {
        //List to hold instance of dropped image files
        List<Image> droppedImages = new List<Image>();
        Popup tipPopup ;
        public DragnDropDemo()
        {
            InitializeComponent();           
        }


       
        private void DropZoneCanvas_Drop(object sender, DragEventArgs e)
        {
           IDataObject data = e.Data;

           FileInfo[] files = (FileInfo[])data.GetData(DataFormats.FileDrop);
           int i = 0;
           foreach (FileInfo file in files)
           {

               if (file.Extension == ".png" || file.Extension == ".jpg")
               {
                   i++;
                   FileStream fs = file.OpenRead();
                   BitmapImage bitmap = new BitmapImage();
                   bitmap.SetSource(fs);
                   Image img = new Image();
                   img.Source = bitmap;
                   img.Height = 120;
                   img.Width = 120;
                   img.Margin = new Thickness(5);
                   img.Stretch = Stretch.Uniform;
                   //attaching MouseLeftButtonDown so uplon click on img will show image in ImageWindow
                   img.MouseLeftButtonDown += new MouseButtonEventHandler(img_MouseLeftButtonDown);
                   ImageBox.Children.Add(img);
                   
               }
               else
               {
                   MessageBox.Show(file.Name + " is not suppored image file.");
               }
           }
        }

        void img_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            ImageWindow iw = new ImageWindow(((Image)sender).Source);
            iw.Show();
        }

        private void DropZoneCanvas_DragOver(object sender, DragEventArgs e)
        {
            //If popup not created, create it.
            if (tipPopup ==null )
            {
                tipPopup = new Popup();
                string message = "Drag and Drop PNG and JPG types images";

                Border border = new Border();
                border.BorderBrush = new SolidColorBrush(Colors.Green);
                border.BorderThickness = new Thickness(2.0);
                border.Background = new SolidColorBrush(Colors.White);

                TextBlock textblock1 = new TextBlock();
                textblock1.Text = message;
                textblock1.Margin = new Thickness(2);
                border.Child = textblock1;
                tipPopup.Child = border;
            }
            //if popup created already above, just update its postion 
            tipPopup.VerticalOffset = e.GetPosition(null).Y;
            tipPopup.HorizontalOffset = e.GetPosition(null).X;
            tipPopup.IsOpen = true;
        }

        private void DropZoneCanvas_DragLeave(object sender, DragEventArgs e)
        {
            tipPopup.IsOpen = false;
        }


        private void CultureList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBoxItem item = CultureList.SelectedItem as ComboBoxItem;
            
            Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo(item.Content.ToString());

            Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo(item.Content.ToString());
            ((LocalizedStrings)App.Current.Resources["LocalizedStrings"]).Resource = new chapter7.Resources.Strings();
        }

                    
        }

       
    }

