﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Windows.Automation;
using System.Windows.Automation.Text;
using System.Diagnostics;
using System.Windows.Automation.Provider;
namespace TestProject1
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public class UnitTest1
    {
        AutomationElement browserInstance;
        public UnitTest1()
        {
            TestMethod1();
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void TestMethod1()
        {
            Process process = null;

            //get the current running instance of iexplore
            foreach (Process p in Process.GetProcessesByName("iexplore"))
            {
                //look for specific window title
                if (p.MainWindowTitle.Contains("chapter15 - Windows Internet Explorer"))
                {
                    process = p;
                    break;
                }
            }
            if (process != null)
            {
                browserInstance = System.Windows.Automation.AutomationElement.FromHandle(process.MainWindowHandle);
            }

            //get reference to Silverlight control
            AutomationElement uiScreen = browserInstance.FindFirst(TreeScope.Descendants, new PropertyCondition(AutomationElement.NameProperty, "Silverlight Control"));
            
            //get reference to all TextBoxes withing the uiScreen
            AutomationElementCollection uiScreenTextBoxes =
            uiScreen.FindAll(TreeScope.Children, new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Edit));
            
            //perform steps to automate UI testing such as 
            //simulating mouse click, keyboard strokes..
            


        }
    }
}
