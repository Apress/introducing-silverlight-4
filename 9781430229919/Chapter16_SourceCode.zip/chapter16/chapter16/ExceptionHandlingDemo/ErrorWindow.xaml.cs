﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace chapter16.ExceptionHandlingDemo
{
    public partial class ErrorWindow : ChildWindow
    {
        public ErrorWindow()
        {
            InitializeComponent();
        }
       
        private void btnSend_Click(object sender, RoutedEventArgs e)
        {
            ////Send error log information to application server using web service 
            // log server can be Log4Net or what you use
            this.DialogResult = true;
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
    }
}

