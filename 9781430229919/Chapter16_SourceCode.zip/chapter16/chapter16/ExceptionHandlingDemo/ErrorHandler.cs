﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace chapter16.ExceptionHandlingDemo
{
    public static class ErrorHandler
    {
        public static string ErrorMsg { get; set; }
        public static string ErrorStackTrace { get; set; }

        public static void ReportError()
        {
            ErrorWindow errwindow = new ErrorWindow();
            errwindow.Title = "An exception has occured.";
            errwindow.txtErrorMsg.Text  = ErrorMsg;
            errwindow.txtErrorStackTrace.Text  = ErrorStackTrace;
            errwindow.Show();
        }

    }
}
