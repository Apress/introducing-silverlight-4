﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
//added
using System.Data.Services.Client;
using WCFDataServiceDemo.DSProxy.ApressBooksModel;


namespace WCFDataServiceDemo
{
    public partial class MainPage : UserControl
    {
        //Dynamic Data context creation
        DataServiceCollection<Book> books = new DataServiceCollection<Book>();

        //Entity context
        ApressBooksEntities context = new ApressBooksEntities(new Uri("DBService.svc", UriKind.Relative));
               
        public MainPage()
        {
            InitializeComponent();
            //Appropriate merge option set for context
            context.MergeOption = MergeOption.PreserveChanges;

        }

        private void btnGetData_Click(object sender, RoutedEventArgs e)
        {          
            //LINQ to Entity
            //var q = (from c in context.Books select c );

            //LINQ to Entity with Eager loading using Expand
            var q = (from c in context.Books.Expand("BookDetails") select c);

            //Async call to load data
            books.LoadAsync(q);
            
            //Async load completed event
            books.LoadCompleted += new EventHandler<LoadCompletedEventArgs>(books_LoadCompleted);
        }

        void books_LoadCompleted(object sender, LoadCompletedEventArgs e)
        {
            if (e.Error==null)
	        {
                BookDataGrid.ItemsSource = books;
	        }
        }

        private void btnAdditem_Click(object sender, RoutedEventArgs e)
        {
            //Adding new item of type Book
            Book b1 = new Book();
            b1.ID = "APB006";
            b1.Title = "Introducing Silverlight 4";
            b1.Author = "Ashish Ghoda";
            b1.Category = "Web Technology";
            b1.SubCategory = "Silverlight, .NET";
            b1.ISBN = "978-1-4302-2991-9";
          
            // Adding new item to context, AddObject can also be used instead.
            context.AddToBooks(b1);

            // Async save changes request to context
            context.BeginSaveChanges(SaveChangesOptions.Batch, (asyncResult) =>
            {
                context.EndSaveChanges(asyncResult);
                
            }, null);

        }

        private void BookDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //Getting reference to current selected book
            Book currentBook = BookDataGrid.SelectedItem as Book;

            //LINQ to get details for the selected book
            var q = from bd in context.Books where bd.ID == currentBook.ID select bd;
            var dsq = (DataServiceQuery<Book>)q;

            //Async execution of the query
            dsq.BeginExecute(result =>
            {
                BookDetailsDataGrid.ItemsSource = dsq.EndExecute(result).FirstOrDefault().BookDetails.ToList();
            }, null);
            

            //Explicit loading (Lazy loading) using BeginLoadPropety
            context.BeginLoadProperty(currentBook , "BookDetails", PropertyLoadCompleted, null);
        }

        private void PropertyLoadCompleted(IAsyncResult result)
        {
            context.EndLoadProperty(result);
            //Getting reference to current selected book
            Book currentBook = BookDataGrid.SelectedItem as Book;
            if (currentBook == null) return;
            
            var query = (from bd in currentBook.BookDetails select bd);
            BookDetailsDataGrid.ItemsSource = query.ToList();
        }
            //Explicit loading (Lazy loading) code end
       
    }

   }
