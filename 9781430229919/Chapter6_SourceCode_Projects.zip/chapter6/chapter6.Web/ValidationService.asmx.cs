﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
//added
using System.Net;
using System.Net.Sockets;
using System.Text.RegularExpressions;
namespace chapter6.Web
{
    /// <summary>
    /// Summary description for ValidationService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class ValidationService : System.Web.Services.WebService
    {
        [WebMethod]
        public bool ValidateUrl(string URL)
        {
            bool isValid = false;
            try
            {
                Dns.GetHostEntry (URL);
                isValid = true;
            }
            catch ( SocketException se)
            {
                isValid = false;
            }
            return isValid;
        }

        [WebMethod]
        public string ValidateEmail(string Email)
        {
            string strRegex = @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}" +
         @"\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\" +
         @".)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$";

            Regex re = new Regex(strRegex);

            if (re.IsMatch(Email) == false)
            {
                return ("E501");
            }
            else if (Email.Substring(Email.IndexOf("@") + 1 ) == "example.com")
            {
                return ("E502");
            }
            return null;

        }
    }
}
