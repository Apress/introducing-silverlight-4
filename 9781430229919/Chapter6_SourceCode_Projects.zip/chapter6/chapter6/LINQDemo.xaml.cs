﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
//added
using System.Xml.Linq;
namespace chapter6
{
    public partial class LINQDemo : UserControl
    {
       public WebClient wc = new WebClient();
        

        public class WebDeveloper
        {
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public string Email { get; set; }
            public string Website { get; set; }
        }

        public LINQDemo()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(LINQDemo_Loaded);
        }

        void LINQDemo_Loaded(object sender, RoutedEventArgs e)
        {
            wc.DownloadStringAsync (new Uri("WebDevelopers.xml", UriKind.RelativeOrAbsolute));
            wc.DownloadStringCompleted += new DownloadStringCompletedEventHandler(wc_DownloadStringCompleted);

        }

        void wc_DownloadStringCompleted(object sender, DownloadStringCompletedEventArgs e)
        {
            XDocument xmlDocument = XDocument.Parse(e.Result);
            var  wdsdata = from b in xmlDocument.Descendants("WebDeveloper")
            select new WebDeveloper
            {
            FirstName = b.Element("FirstName").Value,
            LastName = b.Element("LastName").Value,
            Email = b.Element("Email").Value,
            Website = b.Element("Website").Value,
            };
            outputTextBox.Text = "";
            int count = 1;
            foreach (WebDeveloper wd in wdsdata)
            {
            outputTextBox.Text += "Record #" + count + "\r\n";
            outputTextBox.Text += "----------\r\n";
            outputTextBox.Text += "First Name: " + wd.FirstName + "\r\n";
            outputTextBox.Text += "Last Name: " + wd.LastName + "\r\n";
            outputTextBox.Text += "Email: " +
            string.Format("{0:C}", wd.Email) +"\r\n";
            outputTextBox.Text += "Website: " + wd.Website + "\r\n";

            outputTextBox.Text += "\r\n";
            count++;
            }

        }
    }
}
