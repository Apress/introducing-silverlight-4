﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace chapter6
{
    public class FeesConverter: System.Windows.Data.IValueConverter 
    {
 public object Convert(object value, Type targetType,object parameter,System.Globalization.CultureInfo culture)
        {
            return (String.Format("{0:C}", (double)value));
        }
        public object ConvertBack(object value, Type targetType,
        object parameter,
        System.Globalization.CultureInfo culture)
        {
            string feesbalance = (string)value;
            return (System.Convert.ToDouble(feesbalance.Replace("$", "").Replace(",", "")));
        }

    }
}
