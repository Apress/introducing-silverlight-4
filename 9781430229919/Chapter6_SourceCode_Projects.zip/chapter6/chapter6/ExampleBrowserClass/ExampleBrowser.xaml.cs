﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace chapter6.ExampleBrowserClass
{
    public partial class ExampleBrowser : UserControl
    {
        ExampleItem[] exitems = new ExampleItem[32];

        public ExampleBrowser()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(ExampleBrowser_Loaded);
            //initializing the items
            for (int i = 0; i < 32; i++)
            {
                exitems[i] = new ExampleItem();
            }
        }

        void ExampleBrowser_Loaded(object sender, RoutedEventArgs e)
        {
            CreateItems();
            foreach (var item in exitems )
            {
                TreeViewItem ti = new TreeViewItem();
                ti.Header = item.ExampleName;
                ExampleMenu.Items.Add(ti);
               
            } 
               
            //ExampleMenu.ItemsSource = exitems;
        }

        void CreateItems()
        {
            exitems[0].ExampleName = "Two Way DataBinding";
            exitems[0].ExamplePage = new TwoWayDataBindingDemo();

            exitems[1].ExampleName = "Simple Data Validation";
            exitems[1].ExamplePage = new SimpleDataValidationDemo();

            exitems[2].ExampleName = "IDataErrorInfo";
            exitems[2].ExamplePage = new IDataErrorInfoDemo();

            exitems[3].ExampleName = "INotifyDataErrorInfo";
            exitems[3].ExamplePage = new INotifyDataErrorInfoDemo.AsyncValidationDemo();

            exitems[4].ExampleName = "Element Binding";
            exitems[4].ExamplePage = new ElementBindingDemo();

            exitems[5].ExampleName = "DependencyObject Binding";
            exitems[5].ExamplePage = new DOBindingDemo();

            exitems[6].ExampleName = "String Indexer Binding";
            exitems[6].ExamplePage = new IndexerBindingDemo();

            exitems[7].ExampleName = "PagedCollectionView";
            exitems[7].ExamplePage = new PagedCollectionViewDemo();

            exitems[8].ExampleName = "DataPager";
            exitems[8].ExamplePage = new DataPagerDemo ();

            exitems[9].ExampleName = "DataGrid Sizing";
            exitems[9].ExamplePage = new GridsizingDemo();

            exitems[10].ExampleName = "DataGrid Validation";
            exitems[10].ExamplePage = new DataGridValidation();

            exitems[11].ExampleName = "DataForm";
            exitems[11].ExamplePage = new DataFormDemo();

            exitems[12].ExampleName = "Parsing XML";
            exitems[12].ExamplePage = new ParsingXMLDemo();

            exitems[13].ExampleName = "Serializing XML ";
            exitems[13].ExamplePage = new SerializingXMLDemo();

            exitems[14].ExampleName = "LINQ";
            exitems[14].ExamplePage = new LINQDemo();

        

        }

        private void ExampleMenu_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            TreeViewItem tvi = ExampleMenu.SelectedItem as TreeViewItem ;
            string currentItem = tvi.Header.ToString();
            foreach (var item in exitems )
            {
                if (item.ExampleName == currentItem)
                {
                    ExampleStage.Child = item.ExamplePage;
                    break;
                }
                
            }
        }
    }
}
