﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
//added
using System.Xml;
namespace chapter6
{
    public partial class ParsingXMLDemo : UserControl
    {

        public class WebDeveloper
        {
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public string Email { get; set; }
            public string Website { get; set; }
        }

        public ParsingXMLDemo()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(ParsingXMLDemo_Loaded);
        }

        void ParsingXMLDemo_Loaded(object sender, RoutedEventArgs e)
        {
            List<WebDeveloper> WebDevelopers = new List<WebDeveloper>();
            XmlReaderSettings settings = new XmlReaderSettings();
            settings.IgnoreWhitespace = true;
            XmlReader xmlReader = XmlReader.Create("WebDevelopers.xml", settings);
            while (xmlReader.ReadToFollowing("WebDeveloper"))
            {
                WebDeveloper wd = new WebDeveloper();
                xmlReader.ReadToDescendant("FirstName");
                wd.FirstName = xmlReader.ReadElementContentAsString("FirstName", "");
                wd.LastName = xmlReader.ReadElementContentAsString("LastName", "");
                wd.Email = xmlReader.ReadElementContentAsString("Email", "");
                wd.Website = xmlReader.ReadElementContentAsString("Website", "");

                WebDevelopers.Add(wd);
                dataGrid1.ItemsSource = WebDevelopers;
            }

        }
    }
}
