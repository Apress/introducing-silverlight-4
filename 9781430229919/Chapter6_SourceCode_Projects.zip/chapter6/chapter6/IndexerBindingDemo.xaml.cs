﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace chapter6
{
    public partial class IndexerBindingDemo : UserControl
    {
        public IndexerBindingDemo()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(IndexerBindingDemo_Loaded);
        }

        void IndexerBindingDemo_Loaded(object sender, RoutedEventArgs e)
        {
            Book b = new Book();
            b.Title = "Introducing Silverlight 4";
            b.Author = "Ashish Ghoda";
            b.extraFields.Add("ISBN", "978-1-4302-2991-9");
            b.extraFields.Add("PreviewUrl", @"http://apress.com/book/view/9781430229919");
            LayoutRoot.DataContext = b;
        }
    }
}
