﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
//added
using System.ComponentModel;
namespace chapter6
{
    public partial class SimpleDataValidationDemo : UserControl
    {
        public SimpleDataValidationDemo()
        {
            InitializeComponent();
            Choice ch = new Choice();
            LayoutRoot.DataContext = ch;
            this.BindingValidationError += new EventHandler<ValidationErrorEventArgs>(SimpleDataValidationDemo_BindingValidationError);
        }

        void SimpleDataValidationDemo_BindingValidationError(object sender, ValidationErrorEventArgs e)
        {
            errMessage.Text = e.Error.ErrorContent.ToString(); 
        }

    }
}
