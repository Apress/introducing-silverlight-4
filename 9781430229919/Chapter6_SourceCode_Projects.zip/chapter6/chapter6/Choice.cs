﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;

namespace chapter6
{
    public class Choice : INotifyPropertyChanged, IDataErrorInfo
    {
        private double _answerValue;
        public double AnswerValue
        {
            get { return _answerValue; }
            set
            {
                if (value < 0 || value > 1)
                {
                    throw new ArgumentException("Can't be less than 0 or greater than 1");
                }
                _answerValue = value;
                if (PropertyChanged != null)
                {
                    this.PropertyChanged(this, new PropertyChangedEventArgs("AnswerValue"));
                }
            }
        }
        public event PropertyChangedEventHandler PropertyChanged;

        string errors = null;
        public string Error
        {
            get { return errors; }

        }

        public string this[string columnName]
        {
            get
            {
                string result = null;
                if (columnName == "AnswerValue")
                {
                    if (AnswerValue < 0 || AnswerValue > 1)
                        result = "Can't be less than 0 or greater than 1";
                }
                return result;
            }
        }
    }
}
