﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
//added
using System.Windows.Data;
using System.ComponentModel;
namespace chapter6
{
    public partial class TwoWayDataBindingDemo : UserControl
    {
        
        //public class WebDeveloper
        //{
        //    public string FirstName { get; set; }
        //    public string LastName { get; set; }
        //    public string Email { get; set; }
        //    public string Website { get; set; }
        //}

        //Uncomment this class and comment out above one as you reach "Enabling Data Change Notification" topic
        public class WebDeveloper : INotifyPropertyChanged
        {
            private string firstName;
            private string lastName;
            private string email;
            private string website;
            private double fees;
            public string FirstName
            {
                get
                {
                    return firstName;
                }
                set
                {
                    firstName = value;
                    RaisePropertyChanged("FirstName");
                }
            }

            public string LastName
            {
                get
                {
                    return lastName;
                }
                set
                {
                    lastName = value;
                    RaisePropertyChanged("LastName");
                }
            }
            public string Email
            {
                get
                {
                    return email;
                }
                set
                {
                    email = value;
                    RaisePropertyChanged("Email");
                }
            }
            public string Website
            {
                get
                {
                    return website;
                }
                set
                {
                    website = value;
                    RaisePropertyChanged("Website");
                }
            }
            public double Fees
            {
                get
                {
                    return fees;
                }
                set
                {
                    fees = value;
                    RaisePropertyChanged("Fees");
                }
        }

            public event PropertyChangedEventHandler PropertyChanged;
            public void RaisePropertyChanged(string propertyName)
            {
                if (PropertyChanged != null)
                {
                    PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
                }
            }
        }

        WebDeveloper wd = new WebDeveloper();
        public TwoWayDataBindingDemo()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(TwoWayDataBindingDemo_Loaded);
        }

        void TwoWayDataBindingDemo_Loaded(object sender, RoutedEventArgs e)
        {
            wd.FirstName = "Ashish";
            wd.LastName = "Ghoda";
            wd.Email = "aghoda@TechnologyOpinion.com";
            wd.Website = "www.TechnologyOpinion.com";
            LayoutRoot.DataContext = wd;

            //Binding in code-behind
            Binding dataBinding = new Binding("Website");
            dataBinding.Source = wd;
            dataBinding.Mode = BindingMode.TwoWay;
            websiteTextBox.SetBinding(TextBox.TextProperty, dataBinding);

            //lower half controls
            dsFirstNameTextBox.Text = wd.FirstName;
            dsLastNameTextBox.Text = wd.LastName;
            dsEmailTextBox.Text = wd.Email;
            dsWebsiteTextBox.Text = wd.Website;
        }
        
        private void btnUpdateDataSource_Click(object sender, RoutedEventArgs e)
        {
            //updating data source
            wd.Website = "www.SilverlightStuff.net";  
        }

        private void btnViewDataSourceButton_Click(object sender, RoutedEventArgs e)
        {
            //showing updated data source contents from UI in lower half controls
            dsFirstNameTextBox.Text = wd.FirstName;
            dsLastNameTextBox.Text = wd.LastName;
            dsEmailTextBox.Text = wd.Email;
            dsWebsiteTextBox.Text = wd.Website;
        }
    }
}
