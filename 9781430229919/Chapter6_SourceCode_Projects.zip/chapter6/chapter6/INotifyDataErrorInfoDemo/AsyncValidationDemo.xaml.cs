﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace chapter6.INotifyDataErrorInfoDemo
{
    public partial class AsyncValidationDemo : UserControl
    {

        private Consultant cs;
        public AsyncValidationDemo()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(AsyncValidationDemo_Loaded);
        }

        void AsyncValidationDemo_Loaded(object sender, RoutedEventArgs e)
        {
            cs = new Consultant();
            this.DataContext = cs;
        }

       private void LayoutRoot_BindingValidationError(object sender, ValidationErrorEventArgs e)
        {
            if (cs.HasErrors)
            {
                btnSubmit.IsEnabled = false;
            }
            else
            {
                btnSubmit.IsEnabled = true;
            }
        }
    }
}
