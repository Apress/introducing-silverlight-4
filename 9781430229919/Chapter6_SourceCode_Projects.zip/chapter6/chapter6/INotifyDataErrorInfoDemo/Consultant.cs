﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
//added
using System.ComponentModel;
using System.Collections.Generic;
using System.Linq;

namespace chapter6.INotifyDataErrorInfoDemo
{
    public class Consultant:INotifyDataErrorInfo
    {
        public Consultant()
        {
            vds.ValidateEmailCompleted += new EventHandler<ValidationServiceReference.ValidateEmailCompletedEventArgs>(vds_ValidateEmailCompleted);
            vds.ValidateUrlCompleted += new EventHandler<ValidationServiceReference.ValidateUrlCompletedEventArgs>(vds_ValidateUrlCompleted);
        }

        public class ErrorInfo 
        {
            public ErrorInfo(string Code, String Message)
            {
                this.ErrorCode = Code;
                this.ErrorMessage = Message;
            }
            public string ErrorCode { get; set; }
            public string ErrorMessage { get; set; }
            public override string ToString()
            {
                return ErrorCode + ": " + ErrorMessage;
            }
        }

        #region private members
        private ValidationServiceReference.ValidationServiceSoapClient vds = new ValidationServiceReference.ValidationServiceSoapClient();
        private string name;
        private string email;
        private string websiteurl;
        #endregion

        #region public members
        public Dictionary<string, List<ErrorInfo>> Errors = new Dictionary<string, List<ErrorInfo>>();
        
        public string Name
        {
            get { return name; }
            set
            {
                name = value;
                if (value==string.Empty)
                {
                    //Add error
                    ErrorInfo er = new ErrorInfo("N501", "Name is required.");
                    addError("Name", er); 
                }
                else
                {
                    //Remove error
                    removeError("Name", "N501");
                }
                if (ErrorsChanged != null)
                    ErrorsChanged(this, new DataErrorsChangedEventArgs("Name"));
            }
        }
        public string Websiteurl
        {
            get { return websiteurl; }
            set
            {
                websiteurl = value;
                vds.ValidateUrlAsync(value);
              
            }
        }
        public string Email
        {
            get { return email; }
            set {
                email = value;
                vds.ValidateEmailAsync(value);
            }
        }
        #endregion

        #region Validation methods
        void vds_ValidateEmailCompleted(object sender, ValidationServiceReference.ValidateEmailCompletedEventArgs e)
        {
            if (e.Result=="E501")
            {
                //Add error
                ErrorInfo er = new ErrorInfo("E501", "Email format is Invalid.");
                addError("Email",er);      
            }
            else
	        {
                //Remove error
                removeError("Email","E501");
        	}

            if (e.Result=="E502")
            {
                //Add error
                ErrorInfo er = new ErrorInfo("E502", "Email provider is not supported.");
                addError("Email",er);      
            }
            else
            {
                //Remove error
                removeError("Email", "E502");
            }
            
        }

        void vds_ValidateUrlCompleted(object sender, ValidationServiceReference.ValidateUrlCompletedEventArgs e)
        {
            if (e.Result)
            {
                //Remove the error
                removeError("Websiteurl", "W501");
            }
            else
            {
                //add the error
                ErrorInfo er = new ErrorInfo("W501", "Website does not exist.");
                addError("Websiteurl", er);
            }
        }

        #endregion

        #region Error add/remove
        private void  addError(string propertyName,ErrorInfo error)
        {
            if (Errors.ContainsKey(propertyName)==true)
            {
                var list = Errors[propertyName];
                list.Add(error);
            }
            else// adding the error to the already existing list
            {
                Errors.Add(propertyName, new List<ErrorInfo>() { error });
            }

            if (ErrorsChanged != null)
                ErrorsChanged(this, new DataErrorsChangedEventArgs(propertyName));
        }

        private void removeError(string propertyName, string errorCode)
        {
            if (Errors.ContainsKey(propertyName))
            {
                var Error = Errors[propertyName].Where<ErrorInfo>(e => e.ErrorCode == errorCode).FirstOrDefault();
                var list = Errors[propertyName];
                list.Remove(Error);

                if (list.Count == 0)//no more errors for this property  
                {
                   Errors.Remove(propertyName);
                }

                if (ErrorsChanged != null)
                    ErrorsChanged(this, new DataErrorsChangedEventArgs(propertyName));

            }
        }
        #endregion

        #region INotifyDataErrorInfo Members
        public event EventHandler<DataErrorsChangedEventArgs> ErrorsChanged;

        public System.Collections.IEnumerable GetErrors(string propertyName)
        {
            if (string.IsNullOrEmpty(propertyName))//retrieve errors for entire entity
            {
                return Errors.Values;
            }
            else
            {
                if (Errors.ContainsKey(propertyName))
                    return Errors[propertyName];
                return null;
            }
        }

        public bool HasErrors
        {
            get
            {
                if (Errors.Count == 0)
                    return false;
                return true;
            }
        }
        #endregion
    }
}
