﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
//added
using System.Collections.Generic;
namespace chapter6
{
    public class Book
    {
       public Dictionary<string, object> extraFields;
       public string Title { get; set; }
       public string Author { get; set; }  
       
        public Book()  
       {  
         extraFields = new Dictionary<string, object>();  
       }  
             
     public object this[string indexer]  
      {  
        get  
        {  
          return (extraFields[indexer]);  
        }  
        set  
        {
            extraFields[indexer] = value;  
        }  
      }
    }  
}

