﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
//added
using System.Xml;
using System.Xml.Serialization;
using System.IO.IsolatedStorage;
using System.IO;

namespace chapter6
{
    public partial class SerializingXMLDemo : UserControl
    {
        List<WebDeveloper> WebDevelopers = new List<WebDeveloper>();

        public class WebDeveloper
        {
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public string Email { get; set; }
            public string Website { get; set; }
        }
        public SerializingXMLDemo()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(SerializingXMLDemo_Loaded);
        }

        void SerializingXMLDemo_Loaded(object sender, RoutedEventArgs e)
        {
            
            XmlReaderSettings settings = new XmlReaderSettings();
            settings.IgnoreWhitespace = true;
            XmlReader xmlReader = XmlReader.Create("WebDevelopers.xml", settings);
            while (xmlReader.ReadToFollowing("WebDeveloper"))
            {
                WebDeveloper wd = new WebDeveloper();
                xmlReader.ReadToDescendant("FirstName");
                wd.FirstName = xmlReader.ReadElementContentAsString("FirstName", "");
                wd.LastName = xmlReader.ReadElementContentAsString("LastName", "");
                wd.Email = xmlReader.ReadElementContentAsString("Email", "");
                wd.Website = xmlReader.ReadElementContentAsString("Website", "");

                WebDevelopers.Add(wd);
                dataGrid1.ItemsSource = WebDevelopers;
            }
        }

        private void btnSerialize_Click(object sender, RoutedEventArgs e)
        {
            XmlSerializer ser = new XmlSerializer(typeof(List<WebDeveloper>));
            using (IsolatedStorageFile rootStore =
            IsolatedStorageFile.GetUserStoreForApplication())
            {
                using (IsolatedStorageFileStream fs =
                new IsolatedStorageFileStream("WebDevelopers.xml",
                FileMode.Create, rootStore))
                {
                    ser.Serialize(fs, WebDevelopers);
                }
            }

        }

        private void btnDeserialize_Click(object sender, RoutedEventArgs e)
        {
            List<WebDeveloper> wds = new List<WebDeveloper>();
            XmlSerializer ser = new XmlSerializer(typeof(List<WebDeveloper>));
            using (IsolatedStorageFile rootStore =
            IsolatedStorageFile.GetUserStoreForApplication())
            {
                using (IsolatedStorageFileStream fs =
                new IsolatedStorageFileStream("WebDevelopers.xml",
                FileMode.Open, rootStore))
                {
                    wds = (List<WebDeveloper>)ser.Deserialize(fs);
                }
            }

        }
        




    }
}
