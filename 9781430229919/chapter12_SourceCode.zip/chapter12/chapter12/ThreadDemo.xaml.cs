﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
//added
using System.Threading;

namespace chapter12
{
    public partial class ThreadDemo : UserControl
    {
        Thread currentThread;
        public ThreadDemo()
        {
            InitializeComponent();
        }

        private void startThreadButton_Click(object sender, RoutedEventArgs e)
        {
            currentThread = new Thread(new ThreadStart(doSomething));
            currentThread.Start();
            statusText.Text = "Thread created and started";
            threadStateText.Text = currentThread.ThreadState.ToString();
        }

        public void doSomething()
        {
            Thread.Sleep(5000); // 5 seconds
            Dispatcher.BeginInvoke(delegate() { 
            statusText.Text = "Work done.";
            //new
            threadStateText.Text = currentThread.ThreadState.ToString();
            });
        }
        
    }
}
