﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
//added
using System.Threading;
using System.ComponentModel;

namespace chapter12
{
    public partial class BackgroundWorkerDemo : UserControl
    {
        class CustomWorkerArgs
        {
            public int index;
            public int sleepTime;
        }

        public TextBlock[] resultNo=new TextBlock[3];
        public TextBlock[] resultBoxes = new TextBlock[3];
        public Button[] bwButtons=new Button[3];
        public BackgroundWorker[] workers = new BackgroundWorker[3];
        public BackgroundWorkerDemo()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(BackgroundWorkerDemo_Loaded);
        }

        void BackgroundWorkerDemo_Loaded(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < resultNo.Length ; i++)
            {
                //container
                StackPanel sp = new StackPanel();
                sp.Orientation = Orientation.Horizontal;
                //result index
                resultNo[i]=new TextBlock();
                resultNo[i].Text = "#" + i.ToString();

                //reult box
                resultBoxes[i] = new TextBlock();
                resultBoxes[i].Text = "Not started.";
                resultBoxes[i].Margin = new Thickness(10, 0, 30, 0);
                
                //button
                bwButtons[i] = new Button();
                bwButtons[i].Content = "Start";
                bwButtons[i].Width = 100;
                bwButtons[i].Height = 26;
                bwButtons[i].Tag = i.ToString();
                
                bwButtons[i].Click += new RoutedEventHandler(buttonTask_Click);

                //add to container
                sp.Children.Add(resultNo[i]);
                sp.Children.Add(resultBoxes [i]);
                sp.Children.Add(bwButtons[i]);

                //add to main container
                LayoutRoot.Children.Add(sp);
            }
        }

        void buttonTask_Click(object sender, RoutedEventArgs e)
        {
                // Tag used to get index for button/text blocks
                int index = Convert.ToInt32(((Button)sender).Tag);
                if (workers[index] != null)
                {
                resultBoxes[index].Text = "Cancelling...";
                workers[index].CancelAsync();
                bwButtons[index].Content = "Start";
                }
                else
                {
                BackgroundWorker worker = new BackgroundWorker();
                worker.WorkerReportsProgress = true;
                worker.WorkerSupportsCancellation = true;
                worker.ProgressChanged +=
                new ProgressChangedEventHandler(worker_ProgressChanged);

                worker.RunWorkerCompleted +=
                new RunWorkerCompletedEventHandler(worker_RunWorkerCompleted);
                worker.DoWork += new DoWorkEventHandler(performLengthyOperation);
                CustomWorkerArgs args = new CustomWorkerArgs();
                args.index = index;
                args.sleepTime = 25000;
                bwButtons[index].Content = "Cancel";
                resultBoxes[index].Text = "Starting...";
                workers[index] = worker;
                worker.RunWorkerAsync(args);
                }
        }
        void worker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            int index = ((CustomWorkerArgs)e.UserState).index;
            resultBoxes[index].Text = "In progress: " + e.ProgressPercentage + "%";
        }

        public void performLengthyOperation(object sender, DoWorkEventArgs e)
        {
            BackgroundWorker bw = (BackgroundWorker)sender;
            CustomWorkerArgs args = (CustomWorkerArgs)e.Argument;
            e.Result = args;
            for (int i = 1; i <= 10; i++)
            {
                if (bw.CancellationPending)
                {
                    e.Cancel = true;
                    break;
                }
                else
                {
                    Thread.Sleep(args.sleepTime / 10);
                    bw.ReportProgress(i * 10, args);
                }
            }
        }

        void worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            BackgroundWorker bw = (BackgroundWorker)sender;
            int index;
            if (e.Error != null || e.Cancelled)
            {
                // if there's an Error or this worker was cancelled,
                // we can't access Result without throwing an exception
                if (bw == workers[0])
                    index = 0;
                else if (bw == workers[1])
                    index = 1;
                else
                    index = 2;
                if (e.Error != null)
                    resultBoxes[index].Text = "Exception: " + e.Error.Message;
                else
                    resultBoxes[index].Text = "Cancelled";
            }
            else
            {
                index = ((CustomWorkerArgs)e.Result).index;
                resultBoxes[index].Text = "Completed";
            }
            bwButtons[index].Content = "Start";
            workers[index] = null;
        }
    }
}
