﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
//added
using System.Threading;
using System.Windows.Threading;
namespace chapter12
{
    public partial class TimersDemo : UserControl
    {
        Timer threadTimer;
        private int count = 0;
        DispatcherTimer timer;
        public TimersDemo()
        {
            InitializeComponent();
        }
        private void timerButton_Click(object sender, RoutedEventArgs e)
        {
            if (threadTimer != null)
            {
                threadTimer.Change(0, Timeout.Infinite);
                timerButton.Content = "Start Timer";
            }
            else
            {
                if (threadTimer != null)
                    threadTimer.Change(Convert.ToInt32(dueTimeTextBox.Text) * 1000,
                    Convert.ToInt32(periodTextBox.Text) * 1000);
                else
                    threadTimer = new Timer(new TimerCallback(doSomething), null,
                    Convert.ToInt32(dueTimeTextBox.Text) * 1000,
                    Convert.ToInt32(periodTextBox.Text) * 1000);
                timerButton.Content = "Stop Timer";
            }
        }

        private void doSomething(object state)
        {
            Dispatcher.BeginInvoke(
            delegate()
            {
                timerOutputText.Text =
                (Convert.ToInt32(timerOutputText.Text) + 1).ToString();
            });
        }

        private void startTimer_Click(object sender, RoutedEventArgs e)
        {
            if (startTimer.Content.ToString()=="Start Timer")
            {
                timer = new DispatcherTimer();
                timer.Interval = new TimeSpan(0, 0, int.Parse(intervalTimeTextBox.Text));
                timer.Tick += new EventHandler(timer_Tick);
                timer.Start();
                startTimer.Content = "Stop Timer";
            }
            else
            {
                timer.Stop();
                startTimer.Content = "Start Timer";
            }
        }
        void timer_Tick(object sender, EventArgs e)
        {
            count++;
            outputText.Text = "Tick count: " + count;
            if (count == 20)
                ((DispatcherTimer)sender).Stop();
        }

    }
}
