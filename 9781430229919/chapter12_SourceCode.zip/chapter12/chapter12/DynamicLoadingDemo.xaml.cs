﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
//added
using System.Windows.Markup;



namespace chapter12
{
    public partial class DynamicLoadingDemo : UserControl
    {
        public DynamicLoadingDemo()
        {
            InitializeComponent();
            
        }

        private void btnLoadXAML_Click(object sender, RoutedEventArgs e)
        {
            string xaml= @"<TextBlock xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' Text='Loaded Fragment' Margin='20' Foreground='Red' FontSize='16'/>";
            TextBlock tb = (TextBlock)XamlReader.Load(xaml);
            loadedFragmentBorder.Child = tb;
        }

        private void btnDownloadXAML_Click(object sender, RoutedEventArgs e)
        {
            WebClient wc = new WebClient();
            wc.DownloadStringCompleted +=  new DownloadStringCompletedEventHandler(wc_DownloadStringCompleted);
            wc.DownloadStringAsync(new Uri("XamlFragment.xaml", UriKind.Relative));
        }

        void wc_DownloadStringCompleted(object sender,DownloadStringCompletedEventArgs e)
        {
            TextBlock tb = (TextBlock)XamlReader.Load(e.Result);
            downloadedFragmentBorder.Child = tb;
        }


    }
}
