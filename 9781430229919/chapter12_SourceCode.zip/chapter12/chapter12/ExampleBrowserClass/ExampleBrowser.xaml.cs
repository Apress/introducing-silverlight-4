﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace chapter12.ExampleBrowserClass
{
    public partial class ExampleBrowser : UserControl
    {
        ExampleItem[] exitems = new ExampleItem[6];

        public ExampleBrowser()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(ExampleBrowser_Loaded);
            //initializing the items
            for (int i = 0; i < 6; i++)
            {
                exitems[i] = new ExampleItem();
            }
        }

        void ExampleBrowser_Loaded(object sender, RoutedEventArgs e)
        {
            CreateItems();
            foreach (var item in exitems )
            {
                TreeViewItem ti = new TreeViewItem();
                ti.Header = item.ExampleName;
                ExampleMenu.Items.Add(ti);
               
            } 
               
            //ExampleMenu.ItemsSource = exitems;
        }

        void CreateItems()
        {
            exitems[0].ExampleName = "Threads";
            exitems[0].ExamplePage = new ThreadDemo  ();

            exitems[1].ExampleName = "ThreadPool";
            exitems[1].ExamplePage = new ThreadPoolDemo  ();

            exitems[2].ExampleName = "BackgroundWorker";
            exitems[2].ExamplePage = new BackgroundWorkerDemo ();

            exitems[3].ExampleName = "Timers";
            exitems[3].ExamplePage = new TimersDemo ();

            exitems[4].ExampleName = "Dynamically loading applications";
            exitems[4].ExamplePage = new DynamicLoadingDemo  ();


        }

        private void ExampleMenu_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            TreeViewItem tvi = ExampleMenu.SelectedItem as TreeViewItem ;
            string currentItem = tvi.Header.ToString();
            foreach (var item in exitems )
            {
                if (item.ExampleName == currentItem)
                {
                    ExampleStage.Child = item.ExamplePage;
                    break;
                }
                
            }
        }
    }
}
