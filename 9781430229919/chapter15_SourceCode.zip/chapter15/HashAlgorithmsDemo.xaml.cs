﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
//added
using System.Security.Cryptography;
using System.IO;
using System.Text;

namespace chapter15
{
    public partial class HashAlgorithmsDemo : UserControl
    {
        public HashAlgorithmsDemo()
        {
            InitializeComponent();
        }

        private void btnCalcHash_Click(object sender, RoutedEventArgs e)
        {
            txtHashKey.Text = Convert.ToBase64String( calculateHash(txtPassword.Text, txtPlainText.Text, new HMACSHA256()));
        }
        byte[] calculateHash(string key, string message,HMAC hashAlgorithm)
        {
            UTF8Encoding encoder = new UTF8Encoding();
            hashAlgorithm.Key = encoder.GetBytes(key);
            byte[] hash =
            hashAlgorithm.ComputeHash(encoder.GetBytes(message));
            //Convert the hash byte array to Base64 string
            string hashinbase64string =
            System.Convert.ToBase64String(hash);
            return (hash);
        }

    }
}
