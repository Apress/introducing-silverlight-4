﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
//added
using chapter15.AuthenticationServiceReference;
using chapter15.RoleServiceReference;
namespace chapter15.UACDemo
{
    public partial class LoginScreen : UserControl
    {
        AuthenticationServiceClient client;
        RoleServiceClient roleClient;
        private List<string> cachedRoles;

        public LoginScreen()
        {
            InitializeComponent();

            //authentication service proxy
            client = new AuthenticationServiceClient();
            client.LoginCompleted += new EventHandler<LoginCompletedEventArgs>(client_LoginCompleted);
            client.LogoutCompleted += new EventHandler<System.ComponentModel.AsyncCompletedEventArgs>(client_LogoutCompleted);

             //role service proxy
             roleClient = new RoleServiceClient();
             roleClient.GetRolesForCurrentUserCompleted += new EventHandler<GetRolesForCurrentUserCompletedEventArgs>(roleClient_GetRolesForCurrentUserCompleted);
        
        }

        void roleClient_GetRolesForCurrentUserCompleted(object sender, GetRolesForCurrentUserCompletedEventArgs e)
        {
            cachedRoles = new List<string>();
            foreach (string role in e.Result)
            {
                cachedRoles.Add(role);
            }

            //bind to combobox
            lstRoles.ItemsSource = cachedRoles;
        }

        public bool isUserInRole(string role)
        {
            return (cachedRoles.Contains(role));
        }


        void client_LogoutCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
        {
            LoginPanel.Visibility = Visibility.Visible;
            MainPanel.Visibility = Visibility.Collapsed;

        }

        void client_LoginCompleted(object sender, LoginCompletedEventArgs e)
        {
            if (e.Result)
            {
                LoginPanel.Visibility = Visibility.Collapsed;
                MainPanel.Visibility = Visibility.Visible;
                roleClient.GetRolesForCurrentUserAsync();
            }
            else
            {
                txtResult.Text = "Incorrect username or password";
            }

        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            client.LoginAsync( txtUsername.Text,txtPassword.Password, null, true);
        }

        private void btnLogout_Click(object sender, RoutedEventArgs e)
        {
            client.LogoutAsync();
        }

      
    }
}
