﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
//added
using System.Security.Cryptography;
using System.IO;
using System.Text;
namespace chapter15
{
    public partial class DataEncryptionDemo : UserControl
    {
        //Initialization Vector
        byte[] initializationVector = { 0x11, 0xAF, 0x0C, 0x07, 0x17, 0xFC, 0xAA, 0x89, 0x09, 0xAE, 0xDA, 0xEA, 0x83, 0x00, 0xC0, 0x90 };

        public DataEncryptionDemo()
        {
            InitializeComponent();
        }

        private void btnEncrypt_Click(object sender, RoutedEventArgs e)
        {
            //generating salt from txtSalt
            byte[]salt=Encoding.Unicode.GetBytes(txtSalt.Text);

            //calling encryption method
            EncryptedText.Text  = Encrypt(deriveBytes(txtPassword.Text,salt , 10),initializationVector, txtTextToEncrypt.Text );
        }

        byte[] calculateHash(string key, string message,HMAC hashAlgorithm)
        {
            UTF8Encoding encoder = new UTF8Encoding();
            hashAlgorithm.Key = encoder.GetBytes(key);
            byte[] hash =
            hashAlgorithm.ComputeHash(encoder.GetBytes(message));
            //Convert the hash byte array to Base64 string
            string hashinbase64string =
            System.Convert.ToBase64String(hash);
            return (hash);
        }

        private byte[] deriveBytes(string input, byte[] salt, int iterations)
        {
            Rfc2898DeriveBytes deriver = new
            Rfc2898DeriveBytes(input, salt, iterations);
            return deriver.GetBytes(16);
        }

        private string Encrypt(byte[] key, byte[] iv, string plaintext)
        {
            AesManaged aes = new AesManaged();
            aes.Key = key;
            aes.IV = iv;
            using (MemoryStream stream = new MemoryStream())
            {
                using (CryptoStream encrypt = new CryptoStream(stream,
                aes.CreateEncryptor(),
                CryptoStreamMode.Write))
                {
                    byte[] plaintextBytes =
                    UTF8Encoding.UTF8.GetBytes(plaintext);
                    encrypt.Write(plaintextBytes, 0, plaintextBytes.Length);
                    encrypt.FlushFinalBlock();
                    encrypt.Close();
                    return Convert.ToBase64String(stream.ToArray());
                }
            }
        }

        private string Decrypt(byte[] key, byte[] iv, string encryptedText)
        {
            AesManaged aes = new AesManaged();
            byte[] encryptedBytes = Convert.FromBase64String(encryptedText);
            aes.Key = key;
            aes.IV = iv;
            using (MemoryStream stream = new MemoryStream())
            {
                using (CryptoStream decrypt =
                new CryptoStream(stream, aes.CreateDecryptor(),
                CryptoStreamMode.Write))
                {
                    decrypt.Write(encryptedBytes, 0, encryptedBytes.Length);
                    decrypt.Flush();
                    decrypt.Close();
                    byte[] decryptedBytes = stream.ToArray();
                    return UTF8Encoding.UTF8.GetString(
                    decryptedBytes, 0,
                    decryptedBytes.Length);
                }
            }
        }

        private void btnDecrypt_Click(object sender, RoutedEventArgs e)
        {
            //generating salt from txtSalt
            byte[]salt=Encoding.Unicode.GetBytes(txtSalt.Text);
            DecryptedText.Text = Decrypt(deriveBytes(txtPassword.Text, salt, 10), initializationVector, EncryptedText.Text);
        }
    }
}
