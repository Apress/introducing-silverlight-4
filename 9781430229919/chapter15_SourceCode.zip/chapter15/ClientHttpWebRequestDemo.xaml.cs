﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
//added
using System.Net.Browser;
using System.IO;
using System.Xml.Linq;

namespace chapter15
{
    public partial class ClientHttpWebRequestDemo : UserControl
    {

        public class StatusUpdates
        {
            public string Message { get; set; }
            public string User { get; set; }
        }
        public ClientHttpWebRequestDemo()
        {
            InitializeComponent();
          
        }

        private void btnGetUpdates_Click(object sender, RoutedEventArgs e)
        {
            string  username = txtUsername.Text ;
            string password = txtPassword.Password;


            string twitterUri = @"http://twitter.com/statuses/friends_timeline.xml";
            string uriString = string.Format(twitterUri, username);
            
            WebClient request = new WebClient();

            //We need to register the prefix to use the ClientHttp networking stack
            WebRequest.RegisterPrefix("http://", WebRequestCreator.ClientHttp);

            //Setting UserDefaultCredentials to false to prevent using credentials from local machine's session
            request.UseDefaultCredentials = false;
            
            //setting credentials
            request.Credentials = new NetworkCredential(username, password);
            
            request.DownloadStringCompleted += new DownloadStringCompletedEventHandler(request_DownloadStringCompleted);

            request.DownloadStringAsync(new Uri(twitterUri));
        }


        void request_DownloadStringCompleted(object sender, DownloadStringCompletedEventArgs e)
        {

            List<StatusUpdates> stcol = new List<StatusUpdates>();
             XDocument xdoc = XDocument.Parse(e.Result.ToString());
 
                stcol = (from status in xdoc.Descendants("status")
                                    select new StatusUpdates
                                   {
                                      Message  = status.Element("text").Value,
                                      User = status.Element("user").Element("screen_name").Value}).ToList();


                lstData.ItemsSource = stcol;

        }
    }
}
