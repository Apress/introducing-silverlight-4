﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Threading;
namespace chapter10
{
    public partial class SplineDemo : UserControl
    {

        private Point controlPoint1 = new Point(0, 100);
        private Point controlPoint2 = new Point(0, 100);

        public SplineDemo()
        {
            InitializeComponent();
        }

        private void btnTest_Click(object sender, RoutedEventArgs e)
        {
            //reset the position of rectangle
            Canvas.SetLeft(rect, 0);
            myStoryboard.Begin();
        }

        private void points_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            // Retrieve the name of slider.
            string name = ((Slider)sender).Name;

            RoutedPropertyChangedEventArgs<double> args = e as RoutedPropertyChangedEventArgs<double>;

            switch (name)
            {
                case "point1X":
                    myFrame.KeySpline.ControlPoint1 = new Point((double)args.NewValue, myFrame.KeySpline.ControlPoint1.Y);
                    controlPoint1.X = 100 * (double)args.NewValue;
                    break;
                case "point1Y":
                    myFrame.KeySpline.ControlPoint1 = new Point(myFrame.KeySpline.ControlPoint1.X, (double)args.NewValue);
                    controlPoint1.Y = 100 - (100 * (double)args.NewValue);
                    break;
                case "point2X":
                    myFrame.KeySpline.ControlPoint2 = new Point((double)args.NewValue, myFrame.KeySpline.ControlPoint2.Y);
                    controlPoint2.X = 100 * (double)args.NewValue;
                    break;
                case "point2Y":
                    myFrame.KeySpline.ControlPoint2 = new Point(myFrame.KeySpline.ControlPoint2.X, (double)args.NewValue);
                    controlPoint2.Y = 100 - (100 * (double)args.NewValue);
                    break;
            }
            //Plot the Bezier curve
            myBezier.Point1 = controlPoint1;
            myBezier.Point2 = controlPoint2;

            //Update the Keyspline points text
            txtPoints.Text = "(" + (decimal.Round((decimal )controlPoint1.X/100,2) )+ "," + (decimal.Round((decimal )controlPoint1.Y/100,2) )  + ")  (" + (decimal.Round((decimal )controlPoint2.X/100,2) ) + "," + (decimal.Round((decimal )controlPoint2.Y/100,2) ) + ")";

            
 
        }
    }
}
