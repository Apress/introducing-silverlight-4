﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace chapter10.ExampleBrowserClass
{
    public partial class ExampleBrowser : UserControl
    {
        ExampleItem[] exitems = new ExampleItem[8];

        public ExampleBrowser()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(ExampleBrowser_Loaded);
            //initializing the items
            for (int i = 0; i < 8; i++)
            {
                exitems[i] = new ExampleItem();
            }
        }

        void ExampleBrowser_Loaded(object sender, RoutedEventArgs e)
        {
            CreateItems();
            foreach (var item in exitems )
            {
                TreeViewItem ti = new TreeViewItem();
                ti.Header = item.ExampleName;
                ExampleMenu.Items.Add(ti);
               
            } 
               
            //ExampleMenu.ItemsSource = exitems;
        }

        void CreateItems()
        {
            exitems[0].ExampleName = "AutoReverse";
            exitems[0].ExamplePage = new AutoReverseDemo();

            exitems[1].ExampleName = "FromToBy Animation";
            exitems[1].ExamplePage = new FromToAnimationDemo();

            exitems[2].ExampleName = "Background Animation";
            exitems[2].ExamplePage = new BackgroundAnimationDemo();

            exitems[3].ExampleName = "KeyFrame Animation";
            exitems[3].ExamplePage = new KeyFrameAnimationDemo ();

            exitems[4].ExampleName = "Interpolation";
            exitems[4].ExamplePage = new InterpolationDemo ();

            exitems[5].ExampleName = "Spline Interpolation";
            exitems[5].ExamplePage = new SplineDemo ();

            exitems[6].ExampleName = "Procedural Animation";
            exitems[6].ExamplePage = new ProceduralAnimationDemo.DemoPage ();

            exitems[7].ExampleName = "3D Animation";
            exitems[7].ExamplePage = new ThreeDAnimationDemo  ();

          
    

        }

        private void ExampleMenu_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            TreeViewItem tvi = ExampleMenu.SelectedItem as TreeViewItem ;
            string currentItem = tvi.Header.ToString();
            foreach (var item in exitems )
            {
                if (item.ExampleName == currentItem)
                {
                    ExampleStage.Child = item.ExamplePage;
                    break;
                }
                
            }
        }
    }
}
