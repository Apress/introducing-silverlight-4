﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace chapter10
{
    public partial class FromToAnimationDemo : UserControl
    {
        Storyboard current = new Storyboard();
        bool movementPaused = false;
        bool rotationPaused = false;

        public FromToAnimationDemo()
        {
            InitializeComponent();
           
        }

  
        private void rectAnimTopRight_Completed(object sender, EventArgs e)
        {
            current = rectAnimBottomLeft;
            rectAnimBottomLeft.Begin();

        }

        private void rectAnimBottomLeft_Completed(object sender, EventArgs e)
        {
            //current is a reference of Storyboard
            //that is used for Pause/Resume
            current = rectAnimTopRight;
            rectAnimTopRight.Begin();

        }

  
        private void movementPauseResumeButton_Click(object sender, RoutedEventArgs e)
        {
            if (current.GetCurrentState() != ClockState.Stopped && !movementPaused)
            {
                current.Pause();
                movementPauseResumeButton.Content = "Resume";
                movementPaused = true;
            }

            else
            {
                current.Resume();
                movementPauseResumeButton.Content = "Pause";
                movementPaused = false;
            }
        }

        private void movementStartStopButton_Click(object sender, RoutedEventArgs e)
        {
            current = rectAnimation;
            rectAnimation.Begin();
        }

        private void rectAnimation_Completed(object sender, EventArgs e)
        {
            current = rectAnimBottomLeft;
            rectAnimBottomLeft.Begin();
        }

        private void rotationPauseResumeButton_Click(object sender, RoutedEventArgs e)
        {
            if (current.GetCurrentState() != ClockState.Stopped && !rotationPaused)
            {
                current.Pause();
                rotationPauseResumeButton.Content = "Resume";
                rotationPaused= true;
            }

            else
            {
                current.Resume();
                rotationPauseResumeButton.Content = "Pause";
                rotationPaused = false;
            }


        }

        private void rotationStartStopButton_Click(object sender, RoutedEventArgs e)
        {
            current = rectRotationAnim;
            rectRotationAnim.Begin();

        }




    }
}
