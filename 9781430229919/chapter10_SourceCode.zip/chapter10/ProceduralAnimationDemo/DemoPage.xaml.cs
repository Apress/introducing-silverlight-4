﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
//added
using System.Windows.Threading;

namespace chapter10.ProceduralAnimationDemo
{
    public partial class DemoPage : UserControl
    {
        private Random rnd = new Random();
        public DemoPage()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(DemoPage_Loaded);
        }

        void DemoPage_Loaded(object sender, RoutedEventArgs e)
        {
            DispatcherTimer timer = new DispatcherTimer();

            timer.Interval = TimeSpan.FromSeconds(0.6);   
            timer.Tick += new EventHandler(timer_Tick);
            timer.Start();
        }

        void timer_Tick(object sender, EventArgs e)
        {
            CreateBubble();
        }

        private Dictionary<Storyboard, Bubble> BubblesTracker = new Dictionary<Storyboard, Bubble>();

        private void CreateBubble()
        {
            Duration duration;

            //Random size for new bubble
            double sizeFactor = (double)(rnd.Next(100, 1000)) / 1000;    

            // New color for each bubble using random variable and fromargb method
            Color color = Color.FromArgb((byte)(255 - (byte)(100 * sizeFactor)), (byte)(rnd.Next(0, 255)), (byte)(rnd.Next(0, 255)), (byte)(rnd.Next(0, 255)));
            

            //bubble transparency by setting Alpha channel of the color
            color.A = (byte)(255 - (byte)(100 * sizeFactor));

            // create a new bubble 
            Bubble bubble = new Bubble();

            //Apply size and color created above
            bubble.BubbleColor = color;
            bubble.BubbleSize = sizeFactor;

            //Left position setting of bubble
            double left = rnd.Next(0, (int)(LayoutRoot.ActualWidth - bubble.ActualWidth));   
            //Top position setting of bubble
            double top = LayoutRoot.ActualHeight;                                            
            
            //Apply position to bubble 
            bubble.SetValue(Canvas.LeftProperty, left);
            bubble.SetValue(Canvas.TopProperty, top);

            // To make bubble look near, set higher z-index 
            bubble.SetValue(Canvas.ZIndexProperty, (int)(sizeFactor * 100)); 

            // Moving closer bubbles faster
            duration = new Duration(TimeSpan.FromSeconds((int)(60 - 50 * sizeFactor)));

            // bubble Storyboard
            Storyboard bubblesStoryboard = new Storyboard();

            //This animates bubble from down to up
            DoubleAnimation goUpBubble = new DoubleAnimation();
            goUpBubble.From = top;
            goUpBubble.To = 0 - bubble.ActualHeight;
            goUpBubble.Duration = duration;

            //This animates bubble sideways using EasingFunction
            DoubleAnimation swayBubble = new DoubleAnimation();
            swayBubble.From = left;
            swayBubble.To = left + 100;
            swayBubble.Duration = duration;
            ElasticEase es = new ElasticEase();
            es.Springiness = 3;
            es.Oscillations = 6;
            swayBubble.EasingFunction = es;

            //Setting Canvas.Top as a target property of goUpBubble double animation
            Storyboard.SetTarget(goUpBubble, bubble);
            Storyboard.SetTargetProperty(goUpBubble, new PropertyPath(Canvas.TopProperty));

            //Setting Canvas.Left as a target property of swayBubble double animation
            Storyboard.SetTarget(swayBubble, bubble);
            Storyboard.SetTargetProperty(swayBubble, new PropertyPath(Canvas.LeftProperty));

            //Adding both animation to storyboard
            bubblesStoryboard.Children.Add(goUpBubble);
            bubblesStoryboard.Children.Add(swayBubble);
            
            // add the bubble to the LayoutRoot canvas
            LayoutRoot.Children.Add(bubble);

            // bubbles tracker dictionary object to remove bubbles from canvas later on as they reach top in completed event.
            BubblesTracker.Add(bubblesStoryboard, bubble);

            //storyboard set up
            bubblesStoryboard.Duration = duration;
            bubblesStoryboard.Completed += new EventHandler(bubblesStoryboard_Completed);
            //starting storyboard
            bubblesStoryboard.Begin();
        }


        void bubblesStoryboard_Completed(object sender, EventArgs e)
        {
            Storyboard sbRef = sender as Storyboard;
            sbRef.Stop();
            Bubble target = BubblesTracker[sbRef];

            //Removing the buble and the animation
            LayoutRoot.Children.Remove(target);
            //Removing the key from BubblesTracker dictionary
            BubblesTracker.Remove(sbRef);
                        
        }
    }
}
