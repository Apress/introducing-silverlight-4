﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace chapter10.ProceduralAnimationDemo
{
    public partial class Bubble : UserControl
    {
        public Color BubbleColor { get; set; }
        public double BubbleSize { get; set; }

        public Bubble()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(Bubble_Loaded);
        }

        void Bubble_Loaded(object sender, RoutedEventArgs e)
        {
            //set bubble color
            ColorStop.Color = BubbleColor;
            //set bubble size through ScaleTransform defined in Xaml
            BubbleScaleTransform.ScaleX = BubbleSize;
            BubbleScaleTransform.ScaleY = BubbleSize;
        }
    }
}
