﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace XAMLTour
{
    public partial class ExampleBrowser : UserControl
    {
        public ExampleBrowser()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(ExampleBrowser_Loaded);
        }

        void ExampleBrowser_Loaded(object sender, RoutedEventArgs e)
        {
            CurrentExampleHolder.Child = new MainPage();
        }

        private void SetCurrentExample(object sender, RoutedEventArgs e)
        {
            Button ClickedButtonRef = sender as Button;
            string ExampleName= ClickedButtonRef.Name.ToString();
            switch (ExampleName )
	        {
                case "MainPage":
                    {
                        CurrentExampleHolder.Child=new MainPage();
                        break;
                    }

                case "ChooseAccount":
                    {
                        CurrentExampleHolder.Child = new ChooseAccount();
                        break;
                    }
                case "RoutedEventExample":
                    {
                        CurrentExampleHolder.Child = new RoutedEventExample();
                        break;
                    }
                case "TemplateBindingExample":
                    {
                        CurrentExampleHolder.Child = new TemplateBindingExample();
                        break;
                    }

	        }

        }
    }
}
