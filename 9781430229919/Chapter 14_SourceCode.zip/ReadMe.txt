Creating Interactive Bing Maps with Silverlight and IronRuby using �Just-Text� Approach
=======================================================================================

Files Included:

1. dlr-20100305 - IronRuby and Silverlight integration binaries
1. bingmaps.zip - Bing Maps binaries
2. SilverlightMap.html - Silverlight Bing Maps application/web page using IronRuby
4. SilverlightMap.xaml - XAML file for application
5. SilverlightMap.rb - IronRuby script file for application

Instructions to run the application:

1. Extract files to a web-server
2. Navigate to SilverlightMap.html

Questions - send email to AskAshish@TechnologyOpinion.com and visit my site SilverlightStuff.net and TechnologyOpinion.com to get the latest updates.

Thank You:
Ashish Ghoda
Founder and President
Technology Opinion LLC
TechnologyOpinion.com
Twitter @ashishghoda
