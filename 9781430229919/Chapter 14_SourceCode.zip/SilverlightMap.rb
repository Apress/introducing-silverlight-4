require "bingmaps/Microsoft.Maps.MapControl"
require "bingmaps/Microsoft.Maps.MapControl.Common"

include System::Windows
include System::Windows::Controls
include System::Windows::Media
include System::Windows::Media::Animation
include Microsoft::Maps::MapControl
include Microsoft::Maps::MapControl::Design

include Microsoft::Scripting::Silverlight
DynamicApplication.current.load_root_visual_from_string File.read("SilverlightMap.xaml")

sm = DynamicApplication.current.root_visual.silverlight_map
sm.map_in_ironruby.mode = AerialMode.new(true)
sm.pause_resume.is_enabled = false

sm.rotate_map.click do |s,e|
  sm.map_in_ironruby.horizontal_alignment = HorizontalAlignment.Left
  sm.map_animation.repeat_behavior = RepeatBehavior.Forever
  sm.map_animation.begin
  sm.pause_resume.is_enabled = true
  sm.pause_resume.content = "Pause"  
end

sm.pause_resume.click do |s,e|
  strbtnContent = sm.pause_resume.content.ToString
  if strbtnContent == "Pause" 
    sm.pause_resume.content = "Resume"
    sm.map_animation.pause
  else
    sm.pause_resume.content = "Pause"
    sm.map_animation.resume
  end
end

sm.stop_reset.click	do |s,e|
  sm.map_animation.stop
  sm.pause_resume.is_enabled = false
  sm.pause_resume.content = "Pause"
  sm.map_in_ironruby.horizontal_alignment = HorizontalAlignment.Center   
end    

[:newyork, :sanfrancisco, :vancouver].each do |city|
  sm.send(city).click do |s,e|
    tag_information = s.Tag.split
    location_Converter = LocationConverter.new
    location_info = location_Converter.ConvertFrom(tag_information[0].ToString)
    sm.map_in_ironruby.SetView(location_info, tag_information[1]);
  end
end

